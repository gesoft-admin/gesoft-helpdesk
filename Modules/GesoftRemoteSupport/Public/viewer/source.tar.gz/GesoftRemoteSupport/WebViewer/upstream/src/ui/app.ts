// CortenDesk web client — main-thread UI shell: top bar, command dock, side panel, connect overlay.
//
// DOM id contract (the Blade view provides some; each is created here if missing, and
// #rd-canvas / #rd-side / #rd-overlay are normalized INTO #rd-viewport on mount):
//   #rd-root       page wrapper (toolbar + viewport); gets data-state="<SessionState>"
//   #rd-toolbar    top bar — brand / control island / avatar, rendered by this module
//   #rd-viewport   region between toolbar and page bottom; holds canvas, side panel, dock, overlay, toast
//   #rd-canvas     <canvas> transferred to the session worker (replaced with a fresh node on reconnect)
//   #rd-dock       floating bottom command bar — input, clipboard, panels
//   #rd-side       right slide-out with Files / Chat / Details tabs; .rd-open = visible
//   #rd-edge       edge strip of shortcuts shown while the side panel is closed
//   #rd-overlay    connect overlay — rendered children: #rd-peer-id (row #rd-field-id, hidden when
//                  the peer id is server-injected or in ?id=), #rd-password, #rd-connect,
//                  #rd-overlay-status, #rd-overlay-error; .rd-hidden hides the overlay
//   #rd-toast      transient notification (created here)
//
// Server-injected config:
//   window.__RD__ = { peerId?, serverKeyB64, wsIdUrl, wsRelayUrl, myId, myName, version?, workerUrl? }
// Worker script resolution order: __RD__.workerUrl → <script data-rd-worker="/rdclient/session.worker.js">
// → 'session.worker.js' resolved next to the built app.js (import.meta.url).

import './app.css';
import type {
  DisplayInfo,
  SessionConfig,
  SessionEvent,
  SessionState,
  SessionStats,
  UiCommand,
} from '../core/contracts';
import {
  attachInput,
  createKeyHandler,
  mapKeyboardTarget,
  type DisplayRect,
  type InputOptions,
  type KeyHandler,
  type KeyTarget,
} from '../input/mouse-keyboard';
import { SoftKeyboardInput, sinkAttributes, type SoftKeyAction, type SoftKey } from '../input/soft-keyboard';
import { trackVisualViewport, type ViewportState } from './viewport';
import { ExtraKeysBar } from './extra-keys-bar';
import { haptic, setHapticsEnabled } from './haptics';
import { ViewTransformer, containRect, type Rect, type View } from '../input/view-transform';
import { CompactKeyboard } from './compact-keyboard';
import { MobileBar, barSide, fullscreenButtonMode, currentOrientation, swappedPrefs, type Orientation } from './mobile-bar';
import { TrackpadMapper } from '../input/touch-trackpad';
import type { TouchOutput } from '../input/touch-direct';
import type { Pt } from '../input/gesture';
import { keyComboCommands, modControlKeys, stickyTextCommands } from '../input/extra-keys';
import { readLocalClipboardText } from '../input/clipboard-cursor';
import {
  BackNotification_BlockInputState,
  BackNotification_PrivacyModeState,
  ControlKey,
  SupportedDecoding_PreferCodec,
} from '../gen/message';
import { RESTART_RECONNECT_TIMEOUT_MS, nextRestartReconnectDelay } from '../core/session-controls';
import { DROP_RECONNECT_TIMEOUT_MS, nextReconnectDelay, shouldAutoReconnect } from '../core/reconnect';
import { buildLockScreenKeyCommand, buildSecurityControlMenu } from './session-controls-menu';
import {
  overlayVersion,
  QUALITY,
  STATE_LABEL,
  buildSessionConfig,
  newSessionId,
  buildKeyPressCommands,
  buildTypeCommands,
  clearSavedHash,
  cursorCss,
  debugEnabled,
  addressBookReady,
  applySwitchDisplay,
  displayToRect,
  escapeHtml,
  formatDuration,
  formatMbps,
  iconHtml,
  loadSavedHash,
  loggedOutFromSearch,
  normalizePeerId,
  peerIdFromSearch,
  placePopover,
  resolveWorkerUrl,
  saveSavedHash,
  setLoggedOutParam,
  type IconName,
  type RdGlobalConfig,
  type ShareInfo,
} from './common';
import { FilePanel } from './file-panel';
import { TerminalPanel } from './terminal-panel';
import { TerminalApp, terminalModeFromSearch } from './terminal-app';
import { consumeTwoFactorCode, renderConnectCard, showTwoFactor, type ConnectCardEls } from './connect-card';
import { CameraPanel } from './camera-panel';
import { MseVideoPlayer } from '../media/mse-video';
import { mseH264Available } from '../media/video';
import {
  adaptFps,
  buildResolutionChoices,
  canUseRemoteCursor,
  codecPreferenceValue,
  mapRemoteCursorToCanvas,
  mergeDisplayRefresh,
  mergePlatformAdditions,
  parseVirtualDisplayCapability,
} from './display-controls';
import { RemoteAudioPlayback, type RemoteAudioContext } from '../media/remote-audio';
import { LocalSessionRecorder, type RecordingSurface } from '../media/session-recorder';
import { VoiceCaptureController, browserVoiceCaptureDeps } from '../media/voice-capture';
import { voiceCallUiModel } from './voice-call-ui';
import { VoiceCallAttemptOwner } from './voice-call-attempt';
import { remoteInputAllowed, type RemoteInputChannel } from './view-only-policy';
import { htl, tl, tn, lowerLabel } from '../i18n';
import {
  loadPrefs,
  resetCommands,
  resetPrefs,
  savePrefs,
  withRememberedOptions,
  resolveInputMode,
  type CodecName,
  type InputMode,
  type InputModePref,
  type SessionPrefs,
} from './session-prefs';
import { isRtcEvent, webRtcFor, type WebRtcHost } from './webrtc-host';

// Back-compat: everything that used to live here is re-exported for tests and
// external importers.
export * from './common';

type RdWindow = Window & { __RD__?: RdGlobalConfig };

type SideTab = 'files' | 'chat' | 'details';
type FitMode = 'fit' | 'actual';

type ChatEntry = { who: 'me' | 'peer'; text: string; at: number };
type UiWorkerEvent =
  | SessionEvent
  | { t: 'audioPcm'; pcm: Float32Array; sampleRate: number; channels: number }
  | { t: 'debug'; tag: string; data: unknown };

type RestartFlow = {
  /** restart: the user restarted the device; drop: the connection died by itself (core/reconnect.ts). */
  kind: 'restart' | 'drop';
  startedAt: number;
  attempt: number;
  config: SessionConfig;
  timer?: ReturnType<typeof setTimeout>;
  stableTimer?: ReturnType<typeof setTimeout>;
  deadlineTimer?: ReturnType<typeof setTimeout>;
  reconnecting: boolean;
};

type Els = ConnectCardEls & {
  root: HTMLElement;
  toolbar: HTMLElement;
  viewport: HTMLElement;
  dock: HTMLElement;
  side: HTMLElement;
  edge: HTMLElement;
  overlay: HTMLElement;
  toast: HTMLElement;
  remoteCursor: HTMLImageElement;
  peerLabel: HTMLElement;
  peerSub: HTMLElement;
  recordingIndicator: HTMLElement;
  btnMonitors: HTMLButtonElement;
  btnFullscreen: HTMLButtonElement;
  btnFit: HTMLButtonElement;
  btnViewOnly: HTMLButtonElement;
  chatList: HTMLElement;
  chatInput: HTMLInputElement;
  voiceCallButton: HTMLButtonElement;
  voiceCallStatus: HTMLElement;
  statCodec: HTMLElement;
  statTransport: HTMLElement;
  statRes: HTMLElement;
  statFps: HTMLElement;
  statBitrate: HTMLElement;
  statDropped: HTMLElement;
  statDuration: HTMLElement;
  statVersion: HTMLElement;
  statDevice: HTMLElement;
  statUser: HTMLElement;
  statPlatform: HTMLElement;
};

const HOME_SCREEN_HINT_KEY = 'cortendesk.rdhomescreenhint.v1';

/**
 * Offer Add to Home Screen: an iPhone/iPod browser tab (no fullscreen API),
 * not already running as a Home Screen app.
 */
export function shouldOfferHomeScreen(
  nav: { userAgent: string; standalone?: boolean },
  fullscreenEnabled: boolean,
): boolean {
  if (nav.standalone === true || fullscreenEnabled) return false;
  return /iPhone|iPod/.test(nav.userAgent);
}

/** After the user pinches or pans, the view does not scroll after the trackpad cursor for this long. */
const USER_PAN_HOLD_MS = 400;
/** Trackpad follow: how far (CSS px) inside the visible edge the cursor is kept. */
const FOLLOW_MARGIN = 40;

/** `v` if it lies in lo..hi, else the point `margin` inside the nearer end (the middle of a narrower span). */
function intoSpan(v: number, lo: number, hi: number, margin: number): number {
  if (hi < lo || (v >= lo && v <= hi)) return v;
  const m = Math.min(margin, (hi - lo) / 2);
  return v < lo ? lo + m : hi - m;
}

/** A phone or tablet: the primary pointer is a finger. */
function coarsePointer(): boolean {
  return typeof matchMedia === 'function' && matchMedia('(pointer: coarse)').matches;
}

function q<T extends Element>(scope: ParentNode, sel: string): T {
  const el = scope.querySelector<T>(sel);
  if (!el) throw new Error(`rdclient: missing element ${sel}`);
  return el;
}

/**
 * Peer permission name (PermissionInfo_Permission) -> the control it governs.
 * Permissions with no control here are tracked but change nothing. Keyboard
 * additionally gates the modifier latches and Type (KEYBOARD_EXTRA_IDS) — the
 * map keeps one canonical id per permission because the peer reports the
 * permission, not the widgets.
 */
export const PERMISSION_CONTROLS: Record<string, { id: string; title: string }> = {
  File: { id: 'rd-btn-files', title: tl('file_transfer') },
  Clipboard: { id: 'rd-btn-clip', title: tl('send_clipboard_remote') },
  Keyboard: { id: 'rd-btn-cad', title: tl('keyboard_shortcuts') },
};

/** Controls beyond the canonical one that a withdrawn Keyboard permission disables. */
const KEYBOARD_EXTRA_IDS = ['rd-lat-ctrl', 'rd-lat-alt', 'rd-key-del', 'rd-btn-type', 'rd-btn-kbd', 'rd-btn-xkeys'];

/** On-screen keyboard keys -> the control keys sent for them. */
const SOFT_KEY_CONTROL: Record<SoftKey, ControlKey> = {
  Backspace: ControlKey.Backspace,
  Enter: ControlKey.Return,
  Delete: ControlKey.Delete,
  Tab: ControlKey.Tab,
};

export class RdApp {
  private cfg: RdGlobalConfig | undefined;
  private el!: Els;
  private canvas!: HTMLCanvasElement;
  private worker: Worker | undefined;
  private rtc: WebRtcHost | undefined;
  private detach: (() => void) | undefined;
  private workerUrl = '';
  private fixedPeerId = '';
  private peerId = '';
  private state: SessionState = 'closed';
  private sessionEpoch = 0;
  private canvasTransferred = false;
  private displays: DisplayInfo[] = [];
  private current = 0;
  private stats: SessionStats | undefined;
  private streamStartMs = 0;
  private ticker: ReturnType<typeof setInterval> | undefined;
  private toastTimer: ReturnType<typeof setTimeout> | undefined;
  private pendingHashHex: string | undefined; // h1 emitted this session, pending persist
  private connectedWithSavedHash = false; // this attempt used a stored hash
  private connectedWithAddressBook = false; // this attempt signed in with an address-book password
  private addressBookRefused = false; // the device refused it: ask for the password instead
  private shareEnded = false; // share page: the console ended the link
  private shareWaitTimer: ReturnType<typeof setTimeout> | undefined; // share page: hint after a long wait
  private sessionHashHex: string | undefined; // h1 of the live session — lets the file panel log in silently
  /** Peer-advertised permissions for THIS session; absent means granted. */
  private permissions: Record<string, boolean> = {};
  private privacyModeSupported = false;
  private privacyModeImpls: { key: string; label: string }[] = [];
  private privacyModeOn = false;
  private privacyModePending = false;
  private activePrivacyImplKey = '';
  private blockInputOn = false;
  private blockInputPending = false;
  private lockAfterSessionEnd = false;
  private reconnectConfig: SessionConfig | undefined;
  private restartFlow: RestartFlow | undefined;
  private terminalSupported = false;
  private cameraSupported = false;

  private filePanel: FilePanel | undefined;
  private terminalPanel: TerminalPanel | undefined;
  private cameraPanel: CameraPanel | undefined;
  private audioPlayback: RemoteAudioPlayback | undefined;
  private recorder: LocalSessionRecorder | undefined;
  private remoteAudioEnabled = true;
  private audioStarted = false;
  private audioMuted = false;
  private audioVolume = 1;
  private clipboardEnabled = true;
  private clipboardSyncPrompt: HTMLElement | undefined;
  private recording = false;
  private recordingStartedMs = 0;
  private videoEl!: HTMLVideoElement;
  /** Set only on insecure origins, where WebCodecs is unavailable. */
  private msePlayer: MseVideoPlayer | undefined;

  // --- chrome state ---------------------------------------------------------
  private viewOnly = false;
  private latchCtrl = false;
  private latchAlt = false;
  private inputMode: InputMode = 'pointer';
  /** The remembered choice behind inputMode ('auto' follows the device). */
  private inputModePref: InputModePref = 'auto';
  private fitMode: FitMode = 'fit';
  private quality: number = QUALITY.balanced;
  private customQuality = 75;
  /** The custom slider, not a preset, is what the peer is using. */
  private customQualityActive = false;
  private customFps = 30;
  private adaptiveFpsTarget = 30;
  private adaptiveFps = false;
  private adaptiveStableSamples = 0;
  private lastDroppedFrames = 0;
  private codecSupport: Array<'auto'|'vp9'|'h264'|'h265'|'vp8'|'av1'> = ['auto'];
  private preferredCodec = 'auto';
  private showRemoteCursor = false;
  private followRemoteCursor = false;
  private followRemoteWindow = false;
  private cursorScale = 1;
  private remoteCursorHot = { x: 0, y: 0 };
  private platformAdditions = '';
  private sideTab: SideTab = 'files';
  private chatLog: ChatEntry[] = [];
  private chatUnread = 0;
  private voiceCall: VoiceCaptureController | undefined;
  private voiceCallState: 'idle'|'preparing'|'waiting'|'connected' = 'idle';
  private readonly voiceCallAttempts = new VoiceCallAttemptOwner();
  /** Secure context + getUserMedia + WebCodecs AudioEncoder; decided once per page. */
  private voiceCallSupported: boolean | undefined;
  private peerWho = ''; // user@host once peerInfo arrives
  private peerPlatform = '';
  private peerVersion = '';
  private keyboardMode: SessionPrefs['keyboardMode'] = 'map';
  private pop: HTMLElement | undefined; // the one open popover
  private popAnchor: HTMLElement | undefined;
  private popCleanup: (() => void) | undefined;
  // --- phones and tablets ----------------------------------------------------
  /** Hidden field the on-screen keyboard types into. */
  private kbdSink!: HTMLTextAreaElement;
  private softKeys!: SoftKeyboardInput;
  /** Physical keys typed into the field (iPad / Bluetooth keyboards). */
  private sinkKeys!: KeyHandler;
  private viewportState: ViewportState | undefined;
  private xkeys!: ExtraKeysBar;
  /** Local zoom / pan of the remote screen (pinch, Fit / 1:1). */
  private readonly view = new ViewTransformer();
  private trackpad: TrackpadMapper | undefined;
  private trackpadOut: TouchOutput | undefined;
  /** Trackpad mode's local cursor. */
  private tpCursor!: HTMLElement;
  private tpCursorFade: ReturnType<typeof setTimeout> | undefined;
  /** Last pinch / pan by the user: the view does not follow the cursor right after it. */
  private lastUserPanAt = 0;
  /** Floating controls replacing the top bar and dock on phones and tablets. */
  private bar: MobileBar | undefined;
  private orientation: Orientation = 'portrait';
  /** Viewport size with no on-screen keyboard, kept while one is open. */
  private fullSize: { w: number; h: number } | undefined;
  /** While the keyboard is open the remote screen keeps its full size and pans instead. */
  private frozenSize: { w: number; h: number } | undefined;
  private viewBeforeKeyboard: View | undefined;
  /** Zoom to put back after an automatic reconnect. */
  private viewBeforeReconnect: View | undefined;
  /** The on-screen keyboard was open when the connection dropped. */
  private keyboardBeforeReconnect = false;
  /** The user pressed Disconnect: whatever ends the session now is not a drop. */
  private userClosing = false;
  /** Last touched point on the remote screen (fraction of the image), kept in view when a keyboard opens. */
  private focusFrac: Pt | undefined;
  /** The compact in-page keyboard (landscape option). */
  private ckbd: CompactKeyboard | undefined;

  mount(): void {
    (window as unknown as { __rdApp?: RdApp }).__rdApp = this; // console/debug handle
    this.cfg = (window as unknown as RdWindow).__RD__;
    this.ensureDom();
    this.renderTopBar();
    this.renderDock();
    this.renderSide();
    this.renderOverlay();
    this.setupSoftKeyboard();
    this.setupExtraKeys();
    if (coarsePointer()) {
      this.setupMobileBar();
      trackVisualViewport(this.el.root, (s) => this.onViewportChange(s));
    }

    const attr = document
      .querySelector('script[data-rd-worker]')
      ?.getAttribute('data-rd-worker');
    this.workerUrl = resolveWorkerUrl(this.cfg?.workerUrl, attr, import.meta.url);

    this.fixedPeerId =
      normalizePeerId(this.cfg?.peerId ?? '') || peerIdFromSearch(location.search) || '';
    if (this.share) {
      this.applyShareMode(this.share);
    } else if (this.fixedPeerId) {
      this.el.fieldId.hidden = true;
      this.el.overlayTarget.hidden = false;
      this.el.overlayPeer.textContent = this.fixedPeerId;
      this.el.peerIdInput.value = this.fixedPeerId;
      this.el.peerLabel.textContent = this.fixedPeerId;
      this.hydrateSavedPassword(this.fixedPeerId);
      this.el.passwordInput.focus();
    } else {
      this.el.fieldId.hidden = false;
      this.el.overlayTarget.hidden = true;
      this.el.peerIdInput.focus();
    }
    // Rewrite the field itself, not just the value read out of it: the saved
    // password is keyed by ID, so "123 456 789" and "123456789" would otherwise
    // look like two different devices, and the user would see their pasted
    // spaces survive a failed connect with no hint as to why.
    this.el.peerIdInput.addEventListener('change', () => {
      this.el.peerIdInput.value = normalizePeerId(this.el.peerIdInput.value);
      this.hydrateSavedPassword(this.el.peerIdInput.value);
    });

    // Saved password (or an address-book password) + fixed peer -> sign
    // straight in. Skipped when ?lo=1 (the user logged out on purpose) so the
    // connect screen stays put. Share links always connect at once.
    if (this.share) {
      if (!this.secureContextProblem()) this.onConnectClick();
    } else if (
      this.fixedPeerId &&
      !loggedOutFromSearch(location.search) &&
      (loadSavedHash(this.fixedPeerId) || addressBookReady(this.cfg, this.fixedPeerId))
    ) {
      this.onConnectClick();
    }

    // Surface it before they type a password and press Connect.
    const blocked = this.secureContextProblem();
    if (blocked) {
      this.setOverlayError(blocked);
    }

    this.ticker = setInterval(() => {
      const start = this.stats?.startedAtMs || this.streamStartMs;
      this.el.statDuration.textContent =
        start && this.state === 'streaming' ? formatDuration(Date.now() - start) : '—';
      if (this.recording && this.recordingStartedMs) {
        const time = this.el.recordingIndicator.querySelector('span');
        if (time) time.textContent = formatDuration(Date.now() - this.recordingStartedMs);
      }
    }, 1000);

    window.addEventListener('beforeunload', () => {
      this.userClosing = true;
      this.endVoiceCall(true);
      this.releaseRemoteSecurityState();
      this.post({ c: 'disconnect' });
    });
  }

  // --- DOM scaffolding -------------------------------------------------------

  private ensureDom(): void {
    let root = document.getElementById('rd-root');
    if (!root) {
      root = document.createElement('div');
      root.id = 'rd-root';
      document.body.appendChild(root);
    }
    let toolbar = document.getElementById('rd-toolbar');
    if (!toolbar) {
      toolbar = document.createElement('div');
      toolbar.id = 'rd-toolbar';
    }
    root.prepend(toolbar);
    let viewport = document.getElementById('rd-viewport');
    if (!viewport) {
      viewport = document.createElement('div');
      viewport.id = 'rd-viewport';
    }
    root.appendChild(viewport);
    let canvas = document.getElementById('rd-canvas') as HTMLCanvasElement | null;
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.id = 'rd-canvas';
    }
    viewport.appendChild(canvas);
    let vid = document.getElementById('rd-video') as HTMLVideoElement | null;
    if (!vid) {
      vid = document.createElement('video');
      vid.id = 'rd-video';
      vid.muted = true; // audio has its own path; a muted element may autoplay
      vid.playsInline = true;
      vid.hidden = true;
    }
    viewport.appendChild(vid);
    this.videoEl = vid;
    // Pre-redesign mount point some cached pages still carry.
    document.getElementById('rd-stats')?.remove();
    const make = (id: string): HTMLElement => {
      let n = document.getElementById(id);
      if (!n) {
        n = document.createElement('div');
        n.id = id;
      }
      viewport.appendChild(n);
      return n;
    };
    const side = make('rd-side');
    const edge = make('rd-edge');
    const overlay = make('rd-overlay');
    const toast = make('rd-toast');
    let remoteCursor = document.getElementById('rd-remote-cursor') as HTMLImageElement | null;
    if (!remoteCursor || remoteCursor.tagName !== 'IMG') {
      remoteCursor?.remove();
      remoteCursor = document.createElement('img');
      remoteCursor.id = 'rd-remote-cursor';
      remoteCursor.alt = '';
      remoteCursor.hidden = true;
      viewport.appendChild(remoteCursor);
    }
    // The dock sits BELOW the viewport in normal flow, never over it — an
    // overlay here hides exactly the strip of remote screen (the Windows
    // taskbar) an operator most often needs.
    let dock = document.getElementById('rd-dock');
    if (!dock) {
      dock = document.createElement('div');
      dock.id = 'rd-dock';
    }
    root.appendChild(dock);
    root.dataset.state = 'closed';
    viewport.dataset.fit = 'fit';
    // Safari's own pinch would zoom the whole page out from under the session.
    viewport.addEventListener('gesturestart', (e) => e.preventDefault());
    let tpCursor = document.getElementById('rd-tp-cursor');
    if (!tpCursor) {
      tpCursor = document.createElement('div');
      tpCursor.id = 'rd-tp-cursor';
      tpCursor.className = 'rd-stream-only';
      tpCursor.setAttribute('aria-hidden', 'true');
      tpCursor.innerHTML =
        '<svg viewBox="0 0 20 24" width="20" height="24"><path d="M2 2v17l4.6-4.4 3 7 3-1.3-3-6.8H16Z" fill="#fff" stroke="#000" stroke-width="1.5" stroke-linejoin="round"/></svg>';
      tpCursor.hidden = true;
      viewport.appendChild(tpCursor);
    }
    this.tpCursor = tpCursor;
    if (typeof ResizeObserver === 'function') {
      new ResizeObserver(() => this.updateView()).observe(viewport);
    }
    this.canvas = canvas;
    this.el = {
      root,
      toolbar,
      viewport,
      dock,
      side,
      edge,
      overlay,
      toast,
      remoteCursor,
    } as Els; // remaining refs filled by render*()

    this.setupFullscreenBars();
  }

  /**
   * Fullscreen bar toggles (PR #45). In fullscreen both bars slide off-screen
   * and a 60px arrow at each edge slides them back on click — hover-reveal kept
   * stealing the pointer from the remote desktop's own menus and tabs. The
   * side panel dims until hovered and gives back the rows a shown bar covers.
   * Everything resets when fullscreen ends so the windowed layout is untouched.
   */
  private setupFullscreenBars(): void {
    const rootEl = document.getElementById('rd-root');
    const dockEl = document.getElementById('rd-dock');
    const toolbarEl = document.getElementById('rd-toolbar');
    const edgeEl = document.getElementById('rd-edge');
    const sideEl = document.getElementById('rd-side');
    if (!rootEl) return;

    let bottomOpen = false;
    let topOpen = false;

    // The side panel loses the rows a shown bar covers.
    const updateSideLayout = () => {
      if (!sideEl) return;
      if (document.fullscreenElement) {
        const top = topOpen && toolbarEl ? toolbarEl.offsetHeight : 0;
        const bottom = bottomOpen && dockEl ? dockEl.offsetHeight : 0;
        sideEl.style.top = `${top}px`;
        sideEl.style.height = `calc(100vh - ${top}px - ${bottom}px)`;
      } else {
        sideEl.style.top = '';
        sideEl.style.height = '';
      }
    };

    const makeArrow = (id: string, glyph: string): HTMLButtonElement => {
      const btn = document.createElement('button');
      btn.id = id;
      btn.type = 'button';
      btn.className = 'rd-arrow-btn';
      btn.textContent = glyph;
      rootEl.appendChild(btn);
      return btn;
    };

    const bottomArrow = dockEl ? makeArrow('rd-dock-arrow', '\u25b2') : null;
    bottomArrow?.addEventListener('click', () => {
      bottomOpen = !bottomOpen;
      dockEl!.style.transform = bottomOpen ? 'translateY(0)' : 'translateY(100%)';
      bottomArrow.textContent = bottomOpen ? '\u25bc' : '\u25b2';
      bottomArrow.style.bottom = bottomOpen ? `${dockEl!.offsetHeight}px` : '0px';
      updateSideLayout();
    });

    const topArrow = toolbarEl ? makeArrow('rd-toolbar-arrow', '\u25bc') : null;
    topArrow?.addEventListener('click', () => {
      topOpen = !topOpen;
      toolbarEl!.style.transform = topOpen ? 'translateY(0)' : 'translateY(-100%)';
      topArrow.textContent = topOpen ? '\u25b2' : '\u25bc';
      topArrow.style.top = topOpen ? `${toolbarEl!.offsetHeight}px` : '0px';
      updateSideLayout();
    });

    if (edgeEl) {
      edgeEl.addEventListener('mouseenter', () => { edgeEl.style.opacity = '1'; });
      edgeEl.addEventListener('mouseleave', () => {
        if (document.fullscreenElement) edgeEl.style.opacity = '0.30';
      });
    }

    const onFullscreenChange = () => {
      const fs = !!document.fullscreenElement;
      this.syncFullscreenButton();
      if (fs) {
        bottomOpen = false;
        topOpen = false;
        document.body.classList.add('rd-fullscreen-active');
        if (edgeEl) edgeEl.style.opacity = '0.30';
        if (bottomArrow) { bottomArrow.textContent = '\u25b2'; bottomArrow.style.bottom = '0px'; }
        if (topArrow) { topArrow.textContent = '\u25bc'; topArrow.style.top = '0px'; }
      } else {
        document.body.classList.remove('rd-fullscreen-active');
        if (dockEl) dockEl.style.transform = '';
        if (toolbarEl) toolbarEl.style.transform = '';
        if (edgeEl) edgeEl.style.opacity = '';
        if (bottomArrow) bottomArrow.style.bottom = '';
        if (topArrow) topArrow.style.top = '';
      }
      updateSideLayout();
    };

    document.addEventListener('fullscreenchange', onFullscreenChange);
    onFullscreenChange();
  }

  // --- top bar -----------------------------------------------------------------

  private renderTopBar(): void {
    const initials =
      (this.cfg?.myName || this.cfg?.myId || '?')
        .split(/[\s._-]+/)
        .filter(Boolean)
        .slice(0, 2)
        .map((w) => w[0]!.toUpperCase())
        .join('') || '?';
    this.el.toolbar.innerHTML = `
      <div class="rd-tb-brand">
        <img src="/rdclient/logo.png" alt="" width="30" height="30">
        <span class="rd-tb-brandtext">
          <span class="rd-tb-name">Corten<span>Desk</span></span>
          <span class="rd-tb-sub">${htl('rustdesk_remote_console')}</span>
        </span>
      </div>
      <div class="rd-tb-island">
        <span class="rd-peer-chip">
          <span class="rd-status-dot" aria-hidden="true"></span>
          <span class="rd-peer-meta">
            <span class="rd-peer" id="rd-peer-label">—</span>
            <span class="rd-peer-sub" id="rd-peer-sub"></span>
          </span>
        </span>
        <span class="rd-island-sep rd-stream-only" aria-hidden="true"></span>
        <span class="rd-recording-indicator rd-stream-only" id="rd-recording-indicator" hidden aria-live="polite">${htl('rec')} <span>00:00</span></span>
        <button type="button" class="rd-ib rd-stream-only" id="rd-btn-monitors" title="${htl('select_monitor')}" aria-label="${htl('select_monitor')}" aria-haspopup="true" hidden>${iconHtml('monitor')}</button>
        <button type="button" class="rd-ib rd-stream-only" id="rd-btn-fullscreen" title="${htl('fullscreen')}" aria-label="${htl('fullscreen')}" aria-pressed="false">${iconHtml('fullscreen')}</button>
        <button type="button" class="rd-ib rd-stream-only" id="rd-btn-more" title="${htl('more_options')}" aria-label="${htl('more_options')}" aria-haspopup="true">${iconHtml('more')}</button>
        <span class="rd-island-sep rd-stream-only" aria-hidden="true"></span>
        <button type="button" class="rd-chip rd-stream-only" id="rd-btn-fit" aria-haspopup="true" title="${htl('scale_mode')}">
          <span id="rd-fit-label">${htl('fit_screen')}</span>${iconHtml('chevronDown')}
        </button>
        <button type="button" class="rd-chip rd-stream-only" id="rd-btn-viewonly" aria-pressed="false" title="${htl('block_all_input_remote_device')}">
          ${iconHtml('eye')}<span>${htl('view_only')}</span>
        </button>
        <button type="button" class="rd-disconnect rd-stream-only" id="rd-btn-disconnect">${htl('disconnect')}</button>
      </div>
      <div class="rd-tb-user">
        <span class="rd-avatar" title="${escapeHtml(this.cfg?.myName || this.cfg?.myId || '')}">${escapeHtml(initials)}</span>
      </div>`;
    const t = this.el.toolbar;
    this.el.peerLabel = q(t, '#rd-peer-label');
    this.el.peerSub = q(t, '#rd-peer-sub');
    this.el.recordingIndicator = q(t, '#rd-recording-indicator');
    this.el.btnMonitors = q(t, '#rd-btn-monitors');
    this.el.btnFit = q(t, '#rd-btn-fit');
    this.el.btnViewOnly = q(t, '#rd-btn-viewonly');

    this.el.btnMonitors.addEventListener('click', () => this.openMonitorPop());
    this.el.btnFullscreen = q<HTMLButtonElement>(t, '#rd-btn-fullscreen');
    // iPhone Safari has no element fullscreen; a button that only toasts an
    // error is worse than none.
    this.el.btnFullscreen.hidden = document.fullscreenEnabled === false;
    this.el.btnFullscreen.addEventListener('click', () => void this.toggleFullscreen());
    this.syncFullscreenButton();
    q<HTMLButtonElement>(t, '#rd-btn-more').addEventListener('click', (e) =>
      this.openMorePop(e.currentTarget as HTMLElement),
    );
    this.el.btnFit.addEventListener('click', () => this.openFitPop());
    this.el.btnViewOnly.addEventListener('click', () => this.toggleViewOnly());
    q<HTMLButtonElement>(t, '#rd-btn-disconnect').addEventListener('click', () => this.disconnectByUser());
  }

  private disconnectByUser(): void {
    this.userClosing = true;
    this.setLoggedOutFlag(true); // an explicit logout must not auto-login on reload
    this.clearRestartFlow();
    this.endVoiceCall(true);
    this.releaseRemoteSecurityState();
    this.destroyAdvancedPanels();
    this.post({ c: 'disconnect' });
    this.setState('closed');
  }

  /** Share-link page: present when opened from a share link. */
  private get share(): ShareInfo | undefined {
    return this.cfg?.share ?? undefined;
  }

  /**
   * Share-link page: no ID or password to type, and the device's name instead
   * of its ID. The viewer signs in with an empty password, so the device
   * opens its accept window; what the viewer may do is decided there.
   */
  private applyShareMode(share: ShareInfo): void {
    this.el.overlayTarget.hidden = false;
    this.el.overlayPeer.textContent = share.deviceName || share.label;
    this.el.peerLabel.textContent = share.deviceName || share.label;
    this.voiceCallSupported = false;
    this.syncShareCard();
    this.startSharePing(share);
  }

  /**
   * Keep the console's viewer slot while the page is open. When the link
   * ends (revoked, expired) the console answers 410 and the page disconnects.
   * Each answer carries a fresh hbbs ticket: they live only minutes, so a
   * reconnect, or a file or terminal panel, uses the latest one.
   */
  private startSharePing(share: ShareInfo): void {
    const post = (url: string, keepalive = false): Promise<Response> =>
      fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        keepalive,
        headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'X-CSRF-TOKEN': share.csrfToken },
        body: JSON.stringify({ token: share.token, session: share.session }),
      });
    const timer = setInterval(() => {
      post(share.pingUrl)
        .then(async (r) => {
          if (r.status === 410) {
            clearInterval(timer);
            this.endShare();
            return;
          }
          if (!r.ok) return;
          const body = (await r.json().catch(() => ({}))) as { signal_token?: unknown };
          if (typeof body.signal_token === 'string' && body.signal_token) this.refreshSignalToken(body.signal_token);
        })
        .catch(() => undefined); // a missed ping is retried; the slot lapses on its own
    }, Math.max(5, share.pingSeconds) * 1000);
    window.addEventListener('pagehide', () => {
      if (!this.shareEnded) void post(share.endUrl, true).catch(() => undefined);
    });
  }

  private refreshSignalToken(token: string): void {
    if (this.cfg) this.cfg.signalToken = token;
    if (this.reconnectConfig) this.reconnectConfig.signalToken = token;
  }

  private endShare(): void {
    this.shareEnded = true;
    this.clearRestartFlow();
    this.endVoiceCall(true);
    this.releaseRemoteSecurityState();
    this.destroyAdvancedPanels();
    this.post({ c: 'disconnect' });
    this.setState('closed', tl('share_ended'));
  }

  /**
   * A device set to password-only answers an empty password exactly like one
   * that is showing its accept window: with silence. So after a while the
   * share page says what may be wrong instead of waiting without a word.
   */
  private watchShareWait(state: SessionState): void {
    if (!this.share) return;
    if (state !== 'needAccept') {
      clearTimeout(this.shareWaitTimer);
      this.shareWaitTimer = undefined;
      return;
    }
    if (this.shareWaitTimer) return;
    this.shareWaitTimer = setTimeout(() => {
      if (this.state === 'needAccept') this.setOverlayError(tl('share_waiting_long'));
    }, 45_000);
  }

  /** The connect card never asks a share viewer for an ID or password. */
  private syncShareCard(): void {
    if (!this.share) return;
    this.el.fieldId.hidden = true;
    this.el.passwordRow.hidden = true;
    this.el.saveRow.hidden = true;
    const help = this.el.overlay.querySelector<HTMLElement>('.rd-help');
    if (help) help.textContent = tl('share_help');
  }

  private toggleViewOnly(): void {
    this.viewOnly = !this.viewOnly;
    this.el.btnViewOnly.setAttribute('aria-pressed', String(this.viewOnly));
    this.el.btnViewOnly.classList.toggle('rd-on', this.viewOnly);
    // Latched modifiers make no sense with input off; drop them quietly.
    if (this.viewOnly) {
      this.setLatches(false, false);
      this.xkeys.clearLatches();
      this.terminalPanel?.destroy();
      this.terminalPanel = undefined;
      this.removeClipboardSyncOffer();
    }
    this.toast(this.viewOnly ? tl('view_only_input_is_not') : tl('input_enabled'));
  }

  // --- bottom dock ---------------------------------------------------------------

  private renderDock(): void {
    const db = (id: string, icon: IconName, label: string, title = label): string =>
      `<button type="button" class="rd-db" id="${id}" title="${escapeHtml(title)}" aria-label="${escapeHtml(title)}">` +
      `${iconHtml(icon)}<span>${escapeHtml(label)}</span></button>`;
    this.el.dock.innerHTML = `
      <div class="rd-dock-group" role="group" aria-label="${htl('keyboard')}">
        ${db('rd-btn-kbd', 'keyboard', tl('keyboard'), tl('show_hide_on_screen_keyboard')).replace('class="rd-db"', 'class="rd-db rd-coarse-only" aria-pressed="false"')}
        ${db('rd-btn-xkeys', 'keyboard', tl('extra_keys'), tl('extra_keys_title')).replace('class="rd-db"', 'class="rd-db rd-coarse-only" aria-pressed="false"')}
        ${db('rd-lat-ctrl', 'keyboard', 'Ctrl', tl('hold_ctrl_for_clicks_and'))}
        ${db('rd-lat-alt', 'keyboard', 'Alt', tl('hold_alt_for_clicks_and'))}
        ${db('rd-key-del', 'keyboard', 'Del', tl('send_delete'))}
        ${db('rd-btn-cad', 'keyboard', tl('keys'), tl('keyboard_shortcuts'))}
      </div>
      <span class="rd-dock-sep" aria-hidden="true"></span>
      <div class="rd-dock-group" role="group" aria-label="${htl('input_mode')}">
        ${db('rd-mode-pointer', 'pointer', tl('pointer'), tl('pointer_mode_touch_acts_as'))}
        ${db('rd-mode-touch', 'touch', tl('touch'), tl('touch_mode_tap_drag_scroll'))}
      </div>
      <span class="rd-dock-sep" aria-hidden="true"></span>
      <div class="rd-dock-group" role="group" aria-label="${htl('send')}">
        ${db('rd-btn-type', 'typeText', tl('type'), tl('type_text_on_remote_device'))}
        ${db('rd-btn-clip', 'clipboard', tl('clipboard'), tl('send_clipboard_remote'))}
      </div>
      <span class="rd-dock-sep" aria-hidden="true"></span>
      <div class="rd-dock-group" role="group" aria-label="${htl('panels')}">
        ${db('rd-btn-files', 'folderTransfer', tl('file_transfer_2'))}
        ${db('rd-btn-chat', 'chat', tl('chat'))}
        ${db('rd-btn-session', 'info', tl('session'), tl('session_details'))}
      </div>`;
    const d = this.el.dock;
    q<HTMLButtonElement>(d, '#rd-lat-ctrl').addEventListener('click', () =>
      this.setLatches(!this.latchCtrl, this.latchAlt),
    );
    q<HTMLButtonElement>(d, '#rd-lat-alt').addEventListener('click', () =>
      this.setLatches(this.latchCtrl, !this.latchAlt),
    );
    q<HTMLButtonElement>(d, '#rd-btn-kbd').addEventListener('click', () => this.toggleSoftKeyboard());
    q<HTMLButtonElement>(d, '#rd-btn-xkeys').addEventListener('click', () => this.toggleExtraKeys());
    q<HTMLButtonElement>(d, '#rd-key-del').addEventListener('click', () => {
      this.pressControl(ControlKey.Delete, tl('delete_sent'));
    });
    q<HTMLButtonElement>(d, '#rd-btn-cad').addEventListener('click', (e) =>
      this.openKeysPop(e.currentTarget as HTMLElement),
    );
    q<HTMLButtonElement>(d, '#rd-mode-pointer').addEventListener('click', () => this.chooseInputMode('pointer'));
    q<HTMLButtonElement>(d, '#rd-mode-touch').addEventListener('click', () => this.chooseInputMode('touch'));
    this.applyInputModePref(loadPrefs().inputMode);
    q<HTMLButtonElement>(d, '#rd-btn-type').addEventListener('click', (e) =>
      this.openTypePop(e.currentTarget as HTMLElement),
    );
    q<HTMLButtonElement>(d, '#rd-btn-clip').addEventListener('click', () => {
      void this.sendClipboard();
    });
    q<HTMLButtonElement>(d, '#rd-btn-files').addEventListener('click', () => this.openSide('files'));
    q<HTMLButtonElement>(d, '#rd-btn-chat').addEventListener('click', () => this.openSide('chat'));
    q<HTMLButtonElement>(d, '#rd-btn-session').addEventListener('click', () => this.openSide('details'));
  }

  /** The user picked a mode: use it and remember it for the next session. */
  private chooseInputMode(mode: InputMode): void {
    this.applyInputModePref(mode);
    this.rememberPrefs({ inputMode: mode });
    haptic();
  }

  private applyInputModePref(pref: InputModePref): void {
    this.inputModePref = pref;
    this.setInputMode(resolveInputMode(pref, coarsePointer()));
  }

  private setInputMode(mode: InputMode): void {
    if (mode !== 'trackpad') this.trackpad?.reset();
    this.inputMode = mode;
    if (this.tpCursor) this.drawTrackpadCursor();
    this.bar?.setIcon('mode', this.inputModeIcon());
    this.el.dock.querySelector('#rd-mode-pointer')?.classList.toggle('rd-on', mode === 'pointer');
    this.el.dock.querySelector('#rd-mode-touch')?.classList.toggle('rd-on', mode === 'touch');
  }

  private setLatches(ctrl: boolean, alt: boolean): void {
    this.latchCtrl = ctrl;
    this.latchAlt = alt;
    for (const [id, on] of [
      ['rd-lat-ctrl', ctrl],
      ['rd-lat-alt', alt],
    ] as const) {
      const b = this.el.dock.querySelector<HTMLButtonElement>(`#${id}`);
      b?.classList.toggle('rd-on', on);
      b?.setAttribute('aria-pressed', String(on));
    }
  }

  /** Send a single control key as a press (down+up in one message). */
  private pressControl(key: ControlKey, note?: string): void {
    this.post({ c: 'key', down: false, press: true, keyKind: 'control', value: key, modifiers: [] });
    if (note) this.toast(note);
  }

  // --- side panel (Files / Chat / Details) ----------------------------------------

  private renderSide(): void {
    const tab = (id: SideTab, icon: IconName, label: string): string =>
      `<button type="button" class="rd-tab" data-tab="${id}" role="tab" aria-selected="false">` +
      `${iconHtml(icon)}<span>${escapeHtml(label)}</span><i class="rd-badge" hidden></i></button>`;
    this.el.side.innerHTML = `
      <header class="rd-side-head">
        <div class="rd-side-tabs" role="tablist">
          ${tab('files', 'folderTransfer', tl('files'))}
          ${tab('chat', 'chat', tl('chat'))}
          ${tab('details', 'info', tl('details'))}
        </div>
        <button type="button" class="rd-ib" id="rd-side-close" title="${htl('close_panel')}" aria-label="${htl('close_panel')}">${iconHtml('close')}</button>
      </header>
      <div class="rd-side-body">
        <section class="rd-pane" data-pane="files" hidden></section>
        <section class="rd-pane rd-pane-chat" data-pane="chat" hidden>
          <div class="rd-voice-call">
            <button type="button" class="rd-voice-call-btn" id="rd-voice-call" aria-describedby="rd-voice-call-status">${htl('voice_call')}</button>
            <span id="rd-voice-call-status" role="status" aria-live="polite">${htl('voice_calls_are_off')}</span>
          </div>
          <div class="rd-chat-list" id="rd-chat-list"></div>
          <form class="rd-chat-compose" id="rd-chat-form">
            <input type="text" id="rd-chat-input" autocomplete="off" placeholder="${htl('message_remote_user')}" maxlength="2000">
            <button type="submit" class="rd-ib rd-chat-send" title="${htl('send')}" aria-label="${htl('send_message')}">${iconHtml('send')}</button>
          </form>
        </section>
        <section class="rd-pane rd-pane-details" data-pane="details" hidden>
          <dl class="rd-stats-body">
            <div class="rd-stat-row"><dt>${htl('device')}</dt><dd id="rd-stat-device">—</dd></div>
            <div class="rd-stat-row"><dt>${htl('user')}</dt><dd id="rd-stat-user">—</dd></div>
            <div class="rd-stat-row"><dt>${htl('platform')}</dt><dd id="rd-stat-platform">—</dd></div>
            <div class="rd-stat-row"><dt>${htl('peer_version')}</dt><dd id="rd-stat-version">—</dd></div>
            <div class="rd-stat-row"><dt>${htl('codec')}</dt><dd id="rd-stat-codec">—</dd></div>
            <div class="rd-stat-row"><dt>${htl('transport')}</dt><dd id="rd-stat-transport">—</dd></div>
            <div class="rd-stat-row"><dt>${htl('resolution')}</dt><dd id="rd-stat-res">—</dd></div>
            <div class="rd-stat-row"><dt>${htl('fps')}</dt><dd id="rd-stat-fps">—</dd></div>
            <div class="rd-stat-row"><dt>${htl('bitrate')}</dt><dd id="rd-stat-bitrate">—</dd></div>
            <div class="rd-stat-row"><dt>${htl('frames_dropped')}</dt><dd id="rd-stat-dropped">—</dd></div>
            <div class="rd-stat-row"><dt>${htl('duration')}</dt><dd id="rd-stat-duration">—</dd></div>
          </dl>
        </section>
      </div>`;
    this.el.edge.innerHTML = `
      <button type="button" class="rd-edge-btn" data-open="files" title="${htl('file_transfer')}" aria-label="${htl('open_file_transfer')}">${iconHtml('folderTransfer')}</button>
      <button type="button" class="rd-edge-btn" data-open="chat" title="${htl('chat')}" aria-label="${htl('open_chat')}">${iconHtml('chat')}<i class="rd-badge" hidden></i></button>
      <button type="button" class="rd-edge-btn" data-open="details" title="${htl('session_details')}" aria-label="${htl('open_session_details')}">${iconHtml('info')}</button>`;

    const s = this.el.side;
    this.el.chatList = q(s, '#rd-chat-list');
    this.el.chatInput = q(s, '#rd-chat-input');
    this.el.voiceCallButton = q(s, '#rd-voice-call');
    this.el.voiceCallStatus = q(s, '#rd-voice-call-status');
    this.renderVoiceCall();
    this.el.statDevice = q(s, '#rd-stat-device');
    this.el.statUser = q(s, '#rd-stat-user');
    this.el.statPlatform = q(s, '#rd-stat-platform');
    this.el.statVersion = q(s, '#rd-stat-version');
    this.el.statCodec = q(s, '#rd-stat-codec');
    this.el.statTransport = q(s, '#rd-stat-transport');
    this.el.statRes = q(s, '#rd-stat-res');
    this.el.statFps = q(s, '#rd-stat-fps');
    this.el.statBitrate = q(s, '#rd-stat-bitrate');
    this.el.statDropped = q(s, '#rd-stat-dropped');
    this.el.statDuration = q(s, '#rd-stat-duration');

    for (const b of s.querySelectorAll<HTMLButtonElement>('.rd-tab')) {
      b.addEventListener('click', () => this.openSide(b.dataset.tab as SideTab));
    }
    q<HTMLButtonElement>(s, '#rd-side-close').addEventListener('click', () => this.closeSide());
    for (const b of this.el.edge.querySelectorAll<HTMLButtonElement>('.rd-edge-btn')) {
      b.addEventListener('click', () => this.openSide(b.dataset.open as SideTab));
    }
    q<HTMLFormElement>(s, '#rd-chat-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this.sendChatFromInput();
    });
    this.el.voiceCallButton.addEventListener('click', () => { void this.toggleVoiceCall(); });
  }

  private get sideOpen(): boolean {
    return this.el.side.classList.contains('rd-open');
  }

  private openSide(tabName: SideTab): void {
    if (this.state !== 'streaming') {
      this.toast(tl('connect_device_first'));
      return;
    }
    // Same tab, already open -> the dock button acts as a toggle.
    if (this.sideOpen && this.sideTab === tabName) {
      this.closeSide();
      return;
    }
    if (tabName === 'files') {
      if (this.permissions.File === false) {
        this.toast(tl('this_device_does_not_permit'));
        return;
      }
      this.ensureFilePanel();
    }
    this.sideTab = tabName;
    this.el.side.classList.add('rd-open');
    this.el.root.classList.add('rd-side-is-open');
    for (const b of this.el.side.querySelectorAll<HTMLButtonElement>('.rd-tab')) {
      const active = b.dataset.tab === tabName;
      b.classList.toggle('rd-active', active);
      b.setAttribute('aria-selected', String(active));
    }
    for (const p of this.el.side.querySelectorAll<HTMLElement>('.rd-pane')) {
      p.hidden = p.dataset.pane !== tabName;
    }
    for (const [id, on] of [
      ['rd-btn-files', tabName === 'files'],
      ['rd-btn-chat', tabName === 'chat'],
      ['rd-btn-session', tabName === 'details'],
    ] as const) {
      this.el.dock.querySelector(`#${id}`)?.classList.toggle('rd-on', on);
    }
    if (tabName === 'chat') {
      this.chatUnread = 0;
      this.renderChatBadges();
      this.renderChatList();
      this.el.chatInput.focus();
    }
  }

  private closeSide(): void {
    this.el.side.classList.remove('rd-open');
    this.el.root.classList.remove('rd-side-is-open');
    for (const id of ['rd-btn-files', 'rd-btn-chat', 'rd-btn-session']) {
      this.el.dock.querySelector(`#${id}`)?.classList.remove('rd-on');
    }
  }

  /**
   * Config for a connection opened from the live session. It reuses the
   * session's h1 credential and session_id, so the host lets it in without a
   * second password prompt, even after a one-time password has rotated.
   */
  private sideConfig(connType: SessionConfig['connType']): SessionConfig {
    return {
      ...buildSessionConfig(this.cfg!, this.peerId, '', this.sessionHashHex, connType),
      sessionId: this.reconnectConfig?.sessionId,
    };
  }

  // The file panel mounts INSIDE the Files pane. Its FILE_TRANSFER connection
  // reuses this session's h1 credential — no second password prompt.
  private ensureFilePanel(): void {
    if (this.filePanel) {
      this.filePanel.open();
      return;
    }
    const pane = q<HTMLElement>(this.el.side, '[data-pane="files"]');
    this.filePanel = new FilePanel({
      viewport: pane,
      workerUrl: this.workerUrl,
      toast: (msg) => this.toast(msg),
      getConfig: () => {
        if (!this.cfg || this.state !== 'streaming') return null;
        return this.sideConfig('fileTransfer');
      },
    });
    this.filePanel.open();
  }

  private openTerminalPanel(): void {
    if (!remoteInputAllowed(this.viewOnly, 'terminal')) {
      this.toast(tl('remote_terminal_is_unavailable_in'));
      return;
    }
    if (!this.terminalPanel) {
      this.terminalPanel = new TerminalPanel({
        root: this.el.root,
        workerUrl: this.workerUrl,
        toast: (message) => this.toast(message),
        getConfig: () => {
          if (!this.cfg || this.state !== 'streaming' || !this.terminalSupported
              || !remoteInputAllowed(this.viewOnly, 'terminal')) return null;
          return this.sideConfig('terminal');
        },
      });
    }
    this.terminalPanel.open();
  }

  private openCameraPanel(): void {
    if (!this.cameraPanel) {
      this.cameraPanel = new CameraPanel({
        root: this.el.root,
        workerUrl: this.workerUrl,
        toast: (message) => this.toast(message),
        getConfig: () => {
          if (!this.cfg || this.state !== 'streaming' || !this.cameraSupported) return null;
          return this.sideConfig('viewCamera');
        },
      });
    }
    this.cameraPanel.open();
  }

  // --- chat -----------------------------------------------------------------------

  private sendChatFromInput(): void {
    const text = this.el.chatInput.value.trim();
    if (!text || this.state !== 'streaming') return;
    this.post({ c: 'chat', text });
    // No delivery ack exists in the protocol; echo what we sent.
    this.chatLog.push({ who: 'me', text, at: Date.now() });
    this.el.chatInput.value = '';
    this.renderChatList();
  }

  /** Called directly by the Voice call button so getUserMedia retains its user gesture. */
  private async toggleVoiceCall(): Promise<void> {
    if (this.voiceCallState === 'preparing') return;
    if (this.voiceCallState === 'waiting' || this.voiceCallState === 'connected') {
      this.endVoiceCall(true);
      return;
    }
    if (this.state !== 'streaming') {
      this.toast(tl('voice_calls_require_connected_session'));
      return;
    }
    if (this.permissions.Audio === false) {
      this.toast(tl('this_device_does_not_permit_2'));
      return;
    }
    if (!this.remoteAudioEnabled) {
      // The peer drops call audio and never opens its mic while we have
      // remote audio off, so the call would connect and stay silent.
      this.toast(tl('turn_on_receive_remote_audio'));
      return;
    }
    // Same click that grants the mic also unlocks playback of the peer's voice.
    void this.resumeAudioFromUserGesture();
    if (!this.voiceCall) {
      this.voiceCall = new VoiceCaptureController(browserVoiceCaptureDeps(), {
        sendFormat: (sampleRate, channels) => this.post({ c: 'voiceAudioFormat', sampleRate, channels }),
        sendFrame: (data) => this.post({ c: 'voiceAudioFrame', data }),
        onError: (message) => {
          this.toast(message);
          this.endVoiceCall(true);
        },
      });
    }
    // Calling getUserMedia here, before any protocol packet, preserves the direct-click permission gesture.
    const sessionEpoch = this.sessionEpoch;
    const attempt = this.voiceCallAttempts.begin();
    const voiceCall = this.voiceCall;
    this.voiceCallState = 'preparing';
    this.renderVoiceCall();
    const outcome = await this.voiceCallAttempts.wait(attempt, () => voiceCall.prepare());
    if (!outcome.owned) return;
    const prepared = outcome.value;
    if (sessionEpoch !== this.sessionEpoch || this.voiceCallState !== 'preparing') return;
    if (!prepared.ok) {
      this.voiceCallState = 'idle';
      this.renderVoiceCall();
      this.toast(prepared.message ?? tl('microphone_is_unavailable'));
      return;
    }
    const currentPermissions = this.permissions as Record<string, boolean | undefined>;
    if (this.state !== 'streaming' || currentPermissions.Audio === false) {
      this.endVoiceCall(false);
      return;
    }
    this.voiceCallState = 'waiting';
    this.renderVoiceCall();
    this.post({ c: 'voiceCallStart' });
  }

  private onVoiceCall(state: 'waiting'|'accepted'|'rejected'|'closed', detail?: string): void {
    if (state === 'accepted') {
      if (!this.voiceCall?.start()) {
        this.endVoiceCall(true);
        return;
      }
      this.voiceCallState = 'connected';
    } else if (state === 'waiting') {
      this.voiceCallState = 'waiting';
    } else {
      this.voiceCallAttempts?.invalidate();
      this.voiceCall?.stop();
      this.voiceCallState = 'idle';
      if (state === 'rejected') this.toast(tl('voice_call_was_declined'));
      else if (detail) this.toast(detail);
    }
    this.renderVoiceCall();
  }

  private endVoiceCall(sendClose: boolean): void {
    const hadProtocolCall = this.voiceCallState === 'waiting' || this.voiceCallState === 'connected';
    this.voiceCallAttempts?.invalidate();
    this.voiceCall?.stop();
    this.voiceCallState = 'idle';
    this.renderVoiceCall();
    if (sendClose && hadProtocolCall) this.post({ c: 'voiceCallClose' });
  }

  private renderVoiceCall(): void {
    if (!this.el?.voiceCallButton) return;
    this.voiceCallSupported ??= browserVoiceCaptureDeps().available();
    const model = voiceCallUiModel(this.state, this.permissions.Audio !== false, this.voiceCallState, this.voiceCallSupported);
    this.el.voiceCallButton.disabled = model.disabled;
    this.el.voiceCallButton.textContent = model.label;
    this.el.voiceCallButton.setAttribute('aria-label', model.ariaLabel);
    this.el.voiceCallStatus.textContent = model.status;
  }

  private onChat(text: string): void {
    this.chatLog.push({ who: 'peer', text, at: Date.now() });
    if (this.sideOpen && this.sideTab === 'chat') {
      this.renderChatList();
    } else {
      this.chatUnread++;
      this.renderChatBadges();
      this.toast(tl('chat_toast', { text: text.length > 80 ? text.slice(0, 77) + '…' : text }));
    }
  }

  private renderChatList(): void {
    const fmt = (at: number): string => {
      const d = new Date(at);
      return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    };
    this.el.chatList.innerHTML = this.chatLog.length
      ? this.chatLog
          .map(
            (m) =>
              `<div class="rd-msg-row rd-from-${m.who}"><span class="rd-bubble">${escapeHtml(m.text)}</span>` +
              `<span class="rd-msg-time">${fmt(m.at)}</span></div>`,
          )
          .join('')
      : '<div class="rd-chat-empty">' + htl('no_messages_yet_anything_you') + '</div>';
    this.el.chatList.scrollTop = this.el.chatList.scrollHeight;
  }

  private renderChatBadges(): void {
    // The dock chat button gains its badge lazily so renderDock stays simple.
    if (!this.el.dock.querySelector('#rd-btn-chat .rd-badge')) {
      const b = document.createElement('i');
      b.className = 'rd-badge';
      b.hidden = true;
      this.el.dock.querySelector('#rd-btn-chat')?.appendChild(b);
    }
    const label = this.chatUnread > 9 ? '9+' : String(this.chatUnread);
    for (const b of this.el.root.querySelectorAll<HTMLElement>('.rd-badge')) {
      b.hidden = this.chatUnread === 0;
      b.textContent = label;
    }
  }

  // --- popovers ---------------------------------------------------------------------

  private closePop(): void {
    this.popCleanup?.();
    this.popCleanup = undefined;
    this.pop?.remove();
    this.pop = undefined;
    this.popAnchor = undefined;
  }

  /**
   * One popover at a time, anchored to a control. Clicking the same anchor
   * again closes it; outside pointer-down and Esc close it; `up` opens above
   * the anchor (for the dock).
   */
  private openPop(anchor: HTMLElement, build: (pop: HTMLElement) => void, up = false): void {
    if (this.pop && this.popAnchor === anchor) {
      this.closePop();
      return;
    }
    this.closePop();
    const pop = document.createElement('div');
    pop.className = 'rd-pop';
    pop.setAttribute('role', 'menu');
    build(pop);
    this.el.root.appendChild(pop);
    const a = anchor.getBoundingClientRect();
    const r = pop.getBoundingClientRect();
    const placement = placePopover(
      a,
      { width: r.width, height: Math.max(r.height, pop.scrollHeight) },
      { width: window.innerWidth, height: window.innerHeight },
      up,
    );
    pop.style.left = `${placement.left}px`;
    pop.style.top = `${placement.top}px`;
    pop.style.maxHeight = `${placement.maxHeight}px`;
    this.pop = pop;
    this.popAnchor = anchor;

    const onDown = (e: Event): void => {
      const t = e.target as Node;
      if (!pop.contains(t) && !anchor.contains(t)) this.closePop();
    };
    const onKey = (e: KeyboardEvent): void => {
      if (e.key === 'Escape') this.closePop();
    };
    document.addEventListener('pointerdown', onDown, true);
    document.addEventListener('keydown', onKey, true);
    this.popCleanup = () => {
      document.removeEventListener('pointerdown', onDown, true);
      document.removeEventListener('keydown', onKey, true);
    };
  }

  private menuItem(
    icon: IconName | null,
    label: string,
    checked = false,
    action?: string,
    securityId?: string,
  ): string {
    const security = securityId ? ` data-security="${escapeHtml(securityId)}"` : '';
    const advanced = action ? ` data-action="${escapeHtml(action)}"` : '';
    return (
      `<button type="button" class="rd-mi${checked ? ' rd-checked' : ''}" role="menuitem"${security}${advanced}>` +
      `${icon ? iconHtml(icon) : '<span class="rd-mi-pad"></span>'}` +
      `<span class="rd-mi-label">${escapeHtml(label)}</span>` +
      `${checked ? iconHtml('check') : ''}</button>`
    );
  }

  private openMonitorPop(anchor: HTMLElement = this.el.btnMonitors): void {
    this.openPop(anchor, (pop) => {
      const currentDisplay = this.displays[this.current];
      const virtual = parseVirtualDisplayCapability(this.peerPlatform, this.platformAdditions);
      const isVirtualDisplay = !!virtual && currentDisplay?.originalResolution?.width === 0 && currentDisplay.originalResolution.height === 0;
      const fit = { width: Math.round(this.el.viewport.clientWidth), height: Math.round(this.el.viewport.clientHeight) };
      const resolutions = currentDisplay ? buildResolutionChoices({
        supported: currentDisplay.resolutions,
        original: currentDisplay.originalResolution,
        fit,
        isVirtual: isVirtualDisplay,
      }) : [];
      const resolutionHtml = currentDisplay && resolutions.length
        ? '<div class="rd-pop-sep"></div><div class="rd-pop-title">' + htl('resolution') + '</div>' + resolutions.map((resolution) =>
            `<button type="button" class="rd-mi rd-resolution" data-width="${resolution.width}" data-height="${resolution.height}"><span class="rd-mi-pad"></span><span class="rd-mi-label">${escapeHtml(resolution.label)}</span></button>`,
          ).join('') +
          (isVirtualDisplay ? '<button type="button" class="rd-mi" data-custom-resolution><span class="rd-mi-pad"></span><span class="rd-mi-label">' + htl('custom_resolution') + '</span></button>' : '')
        : '';
      const virtualHtml = virtual
        ? '<div class="rd-pop-sep"></div><div class="rd-pop-title">' + htl('virtual_displays') + '</div>' +
          (virtual.impl === 'rustdesk_idd'
            ? [1, 2, 3, 4].map((id) => this.menuItem(null, tl('virtual_display_n', { id }), virtual.rustdeskIds.includes(id), `virtual:${id}`)).join('') +
              this.menuItem(null, tl('unplug_all_virtual_displays'), false, 'virtual:all')
            : this.menuItem(null, tl('add_virtual_display'), false, 'virtual:add') +
              this.menuItem(null, tl('remove_virtual_display'), false, 'virtual:remove') +
              this.menuItem(null, tl('unplug_all_virtual_displays'), false, 'virtual:all'))
        : '';
      pop.innerHTML =
        '<div class="rd-pop-title">' + htl('select_monitor') + '</div>' +
        this.displays.map((display, index) => {
          const label = display.name?.trim() || tl('monitor_n', { n: index + 1 });
          return (
            `<button type="button" class="rd-mon-tile${index === this.current ? ' rd-checked' : ''}" data-idx="${index}" role="menuitem"${display.online ? '' : ' disabled'}>` +
            `<span class="rd-mon-num">${index + 1}</span>` +
            `<span class="rd-mon-meta"><span class="rd-mon-name">${escapeHtml(label)}</span>` +
            `<span class="rd-mon-res">${display.width}×${display.height}${display.online ? '' : ' · offline'}</span></span>` +
            `${index === this.current ? iconHtml('check') : ''}</button>`
          );
        }).join('') + resolutionHtml + virtualHtml;
      for (const button of pop.querySelectorAll<HTMLButtonElement>('.rd-mon-tile')) {
        button.addEventListener('click', () => {
          this.post({ c: 'switchDisplay', index: Number(button.dataset.idx) });
          // Wait for Misc.switch_display before changing geometry/input mapping.
          this.closePop();
        });
      }
      for (const button of pop.querySelectorAll<HTMLButtonElement>('.rd-resolution')) {
        button.addEventListener('click', () => {
          this.post({
            c: 'displayResolution', display: this.current,
            width: Number(button.dataset.width), height: Number(button.dataset.height),
          });
          this.toast(tl('resolution_change_requested'));
          this.closePop();
        });
      }
      pop.querySelector<HTMLButtonElement>('[data-custom-resolution]')?.addEventListener('click', () => {
        const value = window.prompt(tl('custom_resolution_width_height'), `${currentDisplay?.width ?? 1920}×${currentDisplay?.height ?? 1080}`);
        const match = value?.trim().match(/^(\d{2,5})\s*[x×]\s*(\d{2,5})$/i);
        if (!match) return;
        const width = Number(match[1]);
        const height = Number(match[2]);
        if (width < 1 || height < 1 || width > 16384 || height > 16384) return;
        this.post({ c: 'displayResolution', display: this.current, width, height });
        this.closePop();
      });
      for (const button of pop.querySelectorAll<HTMLButtonElement>('[data-action^="virtual:"]')) {
        button.addEventListener('click', () => {
          const action = button.dataset.action?.slice('virtual:'.length);
          if (!virtual || !action) return;
          if (action === 'all') this.post({ c: 'virtualDisplay', display: -1, on: false });
          else if (action === 'add') this.post({ c: 'virtualDisplay', display: 0, on: true });
          else if (action === 'remove') this.post({ c: 'virtualDisplay', display: 0, on: false });
          else {
            const display = Number(action);
            this.post({ c: 'virtualDisplay', display, on: !virtual.rustdeskIds.includes(display) });
          }
          this.toast(tl('virtual_display_change_requested'));
          this.closePop();
        });
      }
    });
  }

  private openMorePop(anchor: HTMLElement): void {
    this.openPop(anchor, (pop) => {
      const security = buildSecurityControlMenu({
        platform: this.peerPlatform,
        permissions: this.permissions,
        privacyModeSupported: this.privacyModeSupported,
        privacyModeImpls: this.privacyModeImpls,
        privacyModeOn: this.privacyModeOn,
        activePrivacyImplKey: this.activePrivacyImplKey,
        blockInputOn: this.blockInputOn,
        lockAfterSessionEnd: this.lockAfterSessionEnd,
        viewOnly: this.viewOnly,
      });
      const securityHtml = security.length
        ? '<div class="rd-pop-sep"></div><div class="rd-pop-title">' + htl('remote_controls') + '</div>'
          + security.map((item) => this.menuItem(null, item.label, item.checked, undefined, item.id)).join('')
        : '';
      const canTerminal = this.terminalSupported && remoteInputAllowed(this.viewOnly, 'terminal');
      const canCamera = this.cameraSupported;
      const tools =
        canTerminal || canCamera
          ? '<div class="rd-pop-sep"></div><div class="rd-pop-title">' + htl('tools') + '</div>' +
            (canTerminal ? this.menuItem(null, tl('remote_terminal'), false, 'terminal') : '') +
            (canCamera ? this.menuItem(null, tl('view_camera'), false, 'camera') : '')
          : '';
      const canRemoteCursor = canUseRemoteCursor(this.peerPlatform, this.displays[this.current]);
      const keyboardHtml = mapKeyboardTarget(this.peerPlatform, this.peerVersion)
        ? '<div class="rd-pop-sep"></div><div class="rd-pop-title">' + escapeHtml(tl('keyboard')) + '</div>' +
          this.menuItem(null, tl('keyboard_map'), this.keyboardMode === 'map', 'keyboard:map') +
          this.menuItem(null, tl('keyboard_translate'), this.keyboardMode === 'legacy', 'keyboard:legacy')
        : '';
      const codecHtml = this.codecSupport.map((codec) =>
        this.menuItem(null, codec === 'auto' ? tl('automatic_codec') : codec.toUpperCase(), this.preferredCodec === codec, `codec:${codec}`),
      ).join('');
      const canAudio = !!this.audioPlayback && this.permissions.Audio !== false;
      const canClipboard = this.permissions.Clipboard !== false;
      const canSendClipboard = canClipboard && remoteInputAllowed(this.viewOnly, 'clipboard');
      const canRecord = this.permissions.Recording !== false && typeof MediaRecorder !== 'undefined';
      const volumePercent = Math.round(this.audioVolume * 100);
      const mediaHtml =
        canAudio || canClipboard || canRecord
          ? '<div class="rd-pop-sep"></div><div class="rd-pop-title">' + htl('session_media') + '</div>' +
            (canAudio
              ? this.menuItem(null, this.audioStarted ? tl('remote_audio_ready') : tl('start_remote_audio'), this.audioStarted, 'audioResume') +
                this.menuItem(null, tl('receive_remote_audio'), this.remoteAudioEnabled, 'audioToggle') +
                this.menuItem(null, tl('mute_playback'), this.audioMuted, 'audioMute') +
                `<label class="rd-media-volume"><span>${htl('volume')}</span><input data-action="audioVolume" type="range" min="0" max="100" value="${volumePercent}"><output>${volumePercent}%</output></label>`
              : '') +
            (canClipboard
              ? this.menuItem(null, tl('text_clipboard'), this.clipboardEnabled, 'clipboardToggle') +
                (canSendClipboard ? this.menuItem(null, tl('sync_local_clipboard_now'), false, 'clipboardSync') : '')
              : '') +
            (canRecord
              ? this.menuItem(null, this.recording ? tl('stop_local_recording') : tl('start_local_recording'), this.recording, 'recording')
              : '')
          : '';
      pop.innerHTML =
        this.menuItem('refresh', tl('refresh_video'), false, 'refresh') +
        // The toolbar's Fit chip is hidden on narrow screens; offer it here.
        '<div class="rd-narrow-only"><div class="rd-pop-sep"></div><div class="rd-pop-title">' + htl('scale_mode') + '</div>' +
        this.menuItem(null, tl('fit_screen'), this.fitMode === 'fit', 'fit:fit') +
        this.menuItem(null, tl('actual_size'), this.fitMode === 'actual', 'fit:actual') + '</div>' +
        '<div class="rd-pop-sep"></div><div class="rd-pop-title">' + htl('image_quality') + '</div>' +
        this.menuItem(null, tl('best'), !this.customQualityActive && this.quality === QUALITY.best, 'quality:best') +
        this.menuItem(null, tl('balanced'), !this.customQualityActive && this.quality === QUALITY.balanced, 'quality:balanced') +
        this.menuItem(null, tl('speed'), !this.customQualityActive && this.quality === QUALITY.speed, 'quality:speed') +
        `<label class="rd-display-slider${this.customQualityActive ? ' rd-checked' : ''}"><span>${htl('custom_quality')}</span><input data-action="customQuality" type="range" min="10" max="100" value="${this.customQuality}"><output>${this.customQuality}</output></label>` +
        '<div class="rd-pop-sep"></div><div class="rd-pop-title">' + htl('frame_rate_and_codec') + '</div>' +
        this.menuItem(null, tl('adaptive_fps'), this.adaptiveFps, 'adaptiveFps') +
        `<label class="rd-display-slider"><span>${this.adaptiveFps ? 'Maximum FPS' : 'Custom FPS'}</span><input data-action="customFps" type="range" min="5" max="120" step="5" value="${this.customFps}"><output>${this.customFps}</output></label>` +
        codecHtml +
        (canRemoteCursor
          ? '<div class="rd-pop-sep"></div><div class="rd-pop-title">' + htl('remote_cursor') + '</div>' +
            this.menuItem(null, tl('show_remote_cursor'), this.showRemoteCursor, 'showRemoteCursor') +
            this.menuItem(null, tl('follow_remote_cursor'), this.followRemoteCursor, 'followRemoteCursor') +
            (this.displays.length > 1 ? this.menuItem(null, tl('follow_remote_window_focus'), this.followRemoteWindow, 'followRemoteWindow') : '') +
            this.menuItem(null, tl('enlarge_remote_cursor'), this.cursorScale > 1, 'cursorScale')
          : '') +
        keyboardHtml +
        this.touchMenuHtml() +
        securityHtml +
        tools +
        mediaHtml +
        '<div class="rd-pop-sep"></div>' +
        this.menuItem(null, tl('reset_settings_defaults'), false, 'resetPrefs') +
        '<div class="rd-pop-note">' + htl('display_and_media_settings_are') + '</div>';
      pop.querySelector<HTMLButtonElement>('[data-action="refresh"]')?.addEventListener('click', () => {
        this.post({ c: 'refresh' });
        this.closePop();
      });
      for (const button of pop.querySelectorAll<HTMLButtonElement>('[data-action^="input:"]')) {
        button.addEventListener('click', () => {
          const mode = button.dataset.action?.slice('input:'.length);
          this.chooseInputMode(mode === 'pointer' || mode === 'trackpad' ? mode : 'touch');
          this.closePop();
        });
      }
      pop.querySelector<HTMLButtonElement>('[data-action="haptics"]')?.addEventListener('click', () => {
        const on = !loadPrefs().haptics;
        setHapticsEnabled(on);
        this.rememberPrefs({ haptics: on });
        haptic();
        this.closePop();
      });
      for (const button of pop.querySelectorAll<HTMLButtonElement>('[data-action^="fit:"]')) {
        button.addEventListener('click', () => {
          const mode: FitMode = button.dataset.action === 'fit:actual' ? 'actual' : 'fit';
          this.setFitMode(mode);
          this.rememberPrefs({ fitMode: mode });
          this.closePop();
        });
      }
      pop.querySelector<HTMLButtonElement>('[data-action="resetPrefs"]')?.addEventListener('click', () => {
        this.resetSessionPrefs();
        this.toast(tl('settings_reset_defaults'));
        this.closePop();
      });
      const qualityValues: Record<string, number> = { best: QUALITY.best, balanced: QUALITY.balanced, speed: QUALITY.speed };
      for (const button of pop.querySelectorAll<HTMLButtonElement>('[data-action^="quality:"]')) {
        button.addEventListener('click', () => {
          const key = button.dataset.action?.slice('quality:'.length) ?? '';
          this.quality = qualityValues[key] ?? QUALITY.balanced;
          this.customQualityActive = false;
          this.post({ c: 'quality', imageQuality: this.quality });
          this.rememberPrefs({ quality: this.quality, customQualityActive: false });
          this.closePop();
        });
      }
      const customQuality = pop.querySelector<HTMLInputElement>('[data-action="customQuality"]');
      customQuality?.addEventListener('input', () => {
        const output = customQuality.parentElement?.querySelector('output');
        if (output) output.textContent = customQuality.value;
      });
      customQuality?.addEventListener('change', () => {
        this.customQuality = Number(customQuality.value);
        this.customQualityActive = true;
        this.post({ c: 'customQuality', quality: this.customQuality });
        this.rememberPrefs({ customQuality: this.customQuality, customQualityActive: true });
      });
      pop.querySelector<HTMLButtonElement>('[data-action="adaptiveFps"]')?.addEventListener('click', () => {
        this.adaptiveFps = !this.adaptiveFps;
        this.adaptiveFpsTarget = this.customFps;
        this.adaptiveStableSamples = 0;
        this.lastDroppedFrames = this.stats?.framesDropped ?? 0;
        this.post({ c: 'customFps', fps: this.adaptiveFpsTarget });
        this.rememberPrefs({ adaptiveFps: this.adaptiveFps });
        this.toast(this.adaptiveFps ? tl('adaptive_fps_enabled_bitrate_remains') : tl('fixed_fps_enabled'));
        this.closePop();
      });
      const customFps = pop.querySelector<HTMLInputElement>('[data-action="customFps"]');
      customFps?.addEventListener('input', () => {
        const output = customFps.parentElement?.querySelector('output');
        if (output) output.textContent = customFps.value;
      });
      customFps?.addEventListener('change', () => {
        this.customFps = Number(customFps.value);
        this.adaptiveFpsTarget = this.customFps;
        this.adaptiveStableSamples = 0;
        this.post({ c: 'customFps', fps: this.adaptiveFpsTarget });
        this.rememberPrefs({ customFps: this.customFps });
      });
      for (const button of pop.querySelectorAll<HTMLButtonElement>('[data-action^="codec:"]')) {
        button.addEventListener('click', () => {
          const codec = button.dataset.action?.slice('codec:'.length) ?? '';
          const prefer = codecPreferenceValue(codec);
          if (prefer === null || !this.codecSupport.includes(codec as never)) return;
          this.preferredCodec = codec;
          this.post({ c: 'preferredCodec', prefer });
          this.rememberPrefs({ codec: codec as CodecName });
          this.closePop();
        });
      }
      const toggleDisplayOption = (action: 'showRemoteCursor'|'followRemoteCursor'|'followRemoteWindow'): void => {
        const enabled = !this[action];
        this[action] = enabled;
        if (action === 'followRemoteCursor' && enabled && !this.showRemoteCursor) {
          this.showRemoteCursor = true;
          this.post({ c: 'displayOption', option: 'showRemoteCursor', enabled: true });
        }
        this.post({ c: 'displayOption', option: action, enabled });
        this.rememberPrefs({
          showRemoteCursor: this.showRemoteCursor,
          followRemoteCursor: this.followRemoteCursor,
          followRemoteWindow: this.followRemoteWindow,
        });
        if (action === 'showRemoteCursor' && !enabled) this.el.remoteCursor.hidden = true;
        this.closePop();
      };
      for (const action of ['showRemoteCursor', 'followRemoteCursor', 'followRemoteWindow'] as const) {
        pop.querySelector<HTMLButtonElement>(`[data-action="${action}"]`)?.addEventListener('click', () => toggleDisplayOption(action));
      }
      for (const mode of ['map', 'legacy'] as const) {
        pop.querySelector<HTMLButtonElement>(`[data-action="keyboard:${mode}"]`)?.addEventListener('click', () => {
          this.keyboardMode = mode;
          this.rememberPrefs({ keyboardMode: mode });
          this.closePop();
        });
      }
      pop.querySelector<HTMLButtonElement>('[data-action="cursorScale"]')?.addEventListener('click', () => {
        this.cursorScale = this.cursorScale > 1 ? 1 : 2;
        this.updateRemoteCursorTransform();
        this.rememberPrefs({ cursorScale: this.cursorScale });
        this.closePop();
      });
      for (const button of pop.querySelectorAll<HTMLButtonElement>('[data-security]')) {
        button.addEventListener('click', () => this.activateSecurityControl(button.dataset.security!));
      }
      pop.querySelector<HTMLButtonElement>('[data-action="terminal"]')?.addEventListener('click', () => {
        this.closePop();
        this.openTerminalPanel();
      });
      pop.querySelector<HTMLButtonElement>('[data-action="camera"]')?.addEventListener('click', () => {
        this.closePop();
        this.openCameraPanel();
      });
      pop.querySelector<HTMLButtonElement>('[data-action="audioResume"]')?.addEventListener('click', () => {
        void this.resumeAudioFromUserGesture();
        this.closePop();
      });
      pop.querySelector<HTMLButtonElement>('[data-action="audioToggle"]')?.addEventListener('click', () => {
        this.remoteAudioEnabled = !this.remoteAudioEnabled;
        this.post({ c: 'remoteAudio', enabled: this.remoteAudioEnabled });
        this.rememberPrefs({ remoteAudio: this.remoteAudioEnabled });
        if (this.remoteAudioEnabled) void this.resumeAudioFromUserGesture();
        else this.audioPlayback?.reset();
        this.toast(this.remoteAudioEnabled ? tl('remote_audio_enabled') : tl('remote_audio_disabled'));
        this.closePop();
      });
      pop.querySelector<HTMLButtonElement>('[data-action="audioMute"]')?.addEventListener('click', () => {
        this.audioMuted = !this.audioMuted;
        this.audioPlayback?.setMuted(this.audioMuted);
        this.rememberPrefs({ audioMuted: this.audioMuted });
        this.toast(this.audioMuted ? tl('remote_audio_muted') : tl('remote_audio_unmuted'));
        this.closePop();
      });
      const volume = pop.querySelector<HTMLInputElement>('[data-action="audioVolume"]');
      volume?.addEventListener('input', () => {
        this.audioVolume = Number(volume.value) / 100;
        this.audioPlayback?.setVolume(this.audioVolume);
        const output = volume.parentElement?.querySelector('output');
        if (output) output.textContent = `${volume.value}%`;
      });
      volume?.addEventListener('change', () => this.rememberPrefs({ audioVolume: this.audioVolume }));
      pop.querySelector<HTMLButtonElement>('[data-action="clipboardToggle"]')?.addEventListener('click', () => {
        this.clipboardEnabled = !this.clipboardEnabled;
        this.post({ c: 'clipboardEnabled', enabled: this.clipboardEnabled });
        this.rememberPrefs({ clipboard: this.clipboardEnabled });
        if (!this.clipboardEnabled) this.removeClipboardSyncOffer();
        this.toast(this.clipboardEnabled ? tl('text_clipboard_enabled') : tl('text_clipboard_disabled'));
        this.closePop();
      });
      pop.querySelector<HTMLButtonElement>('[data-action="clipboardSync"]')?.addEventListener('click', () => {
        this.removeClipboardSyncOffer();
        void this.sendClipboard();
        this.closePop();
      });
      pop.querySelector<HTMLButtonElement>('[data-action="recording"]')?.addEventListener('click', () => {
        void this.toggleRecording();
        this.closePop();
      });
    });
  }

  private activateSecurityControl(id: string): void {
    if (id === 'restart') {
      this.closePop();
      this.beginRemoteRestart();
      return;
    }
    if (id === 'elevation') {
      if (!window.confirm(tl('ask_remote_windows_user_approve'))) return;
      this.post({ c: 'requestElevation' });
      this.toast(tl('elevation_requested_waiting_for_approval'), true);
      this.closePop();
      return;
    }
    if (id.startsWith('privacy:')) {
      if (this.privacyModePending) return;
      const implKey = id.slice('privacy:'.length);
      const on = !(this.privacyModeOn && this.activePrivacyImplKey === implKey);
      if (on && !window.confirm(tl('enable_privacy_mode_and_hide'))) return;
      this.privacyModePending = true;
      this.activePrivacyImplKey = implKey;
      this.post({ c: 'privacyMode', implKey, on });
      this.toast(tl(on ? 'privacy_enabling' : 'privacy_disabling'), true);
      this.closePop();
      return;
    }
    if (id === 'blockInput') {
      if (this.blockInputPending) return;
      const on = !this.blockInputOn;
      if (on && !window.confirm(tl('block_remote_computers_local_keyboard'))) return;
      this.blockInputPending = true;
      this.post({ c: 'blockInput', on });
      this.toast(tl(on ? 'input_blocking' : 'input_restoring'), true);
      this.closePop();
      return;
    }
    if (id === 'lockScreen') {
      const sent = this.post(buildLockScreenKeyCommand());
      this.toast(sent ? tl('lock_command_sent') : tl('lock_command_not_sent'));
      this.closePop();
      return;
    }
    if (id === 'lockAfterSessionEnd') {
      this.lockAfterSessionEnd = !this.lockAfterSessionEnd;
      this.post({ c: 'lockAfterSessionEnd', on: this.lockAfterSessionEnd });
      this.toast(
        this.lockAfterSessionEnd
          ? tl('lock_after_disconnect_request_sent')
          : tl('lock_after_disconnect_disable_request'),
      );
      this.closePop();
    }
  }

  private openFitPop(): void {
    this.openPop(this.el.btnFit, (pop) => {
      pop.innerHTML =
        this.menuItem(null, tl('fit_screen'), this.fitMode === 'fit') +
        this.menuItem(null, tl('actual_size'), this.fitMode === 'actual');
      const items = pop.querySelectorAll<HTMLButtonElement>('.rd-mi');
      const set = (mode: FitMode): void => {
        this.setFitMode(mode);
        this.rememberPrefs({ fitMode: mode });
        this.closePop();
      };
      items[0]?.addEventListener('click', () => set('fit'));
      items[1]?.addEventListener('click', () => set('actual'));
    });
  }

  private setFitMode(mode: FitMode): void {
    this.fitMode = mode;
    if (coarsePointer()) {
      // Phones and tablets zoom the view instead (pinch-able, no scrollbars).
      this.el.viewport.dataset.fit = 'fit';
      this.applyFitZoom();
    } else {
      this.el.viewport.dataset.fit = mode;
    }
    q(this.el.toolbar, '#rd-fit-label').textContent = mode === 'fit' ? tl('fit_screen') : tl('actual_size');
  }

  // --- remembered settings (issue #92) --------------------------------------

  /**
   * Save only the fields the user just changed. Writing the whole live state
   * would also save things the session adjusted on its own, such as a codec
   * this browser cannot decode falling back to automatic.
   */
  private rememberPrefs(patch: Partial<SessionPrefs>): void {
    savePrefs({ ...loadPrefs(), ...patch });
  }

  /** Load remembered settings into the session state, ahead of connecting. */
  private applyPrefs(p: SessionPrefs): void {
    this.quality = p.quality;
    this.customQuality = p.customQuality;
    this.customQualityActive = p.customQualityActive;
    this.customFps = p.customFps;
    this.adaptiveFps = p.adaptiveFps;
    this.adaptiveFpsTarget = p.customFps;
    this.preferredCodec = p.codec;
    this.setFitMode(p.fitMode);
    this.showRemoteCursor = p.showRemoteCursor || p.followRemoteCursor;
    this.followRemoteCursor = p.followRemoteCursor;
    this.followRemoteWindow = p.followRemoteWindow;
    this.cursorScale = p.cursorScale;
    this.updateRemoteCursorTransform();
    this.clipboardEnabled = p.clipboard;
    this.remoteAudioEnabled = p.remoteAudio;
    this.audioMuted = p.audioMuted;
    this.audioVolume = p.audioVolume;
    this.keyboardMode = p.keyboardMode;
    this.applyInputModePref(p.inputMode);
    setHapticsEnabled(p.haptics);
    this.audioPlayback?.setVolume(this.audioVolume);
    this.audioPlayback?.setMuted(this.audioMuted);
  }

  /** Forget remembered settings and put the live session back on the defaults. */
  private resetSessionPrefs(): void {
    const before = this.livePrefs();
    const d = resetPrefs();
    this.applyPrefs(d);
    if (!this.showRemoteCursor) this.el.remoteCursor.hidden = true;
    if (this.state !== 'streaming') return;
    for (const cmd of resetCommands(before, d)) this.post(cmd);
    if (!before.remoteAudio) void this.resumeAudioFromUserGesture();
  }

  private livePrefs(): SessionPrefs {
    return {
      quality: this.quality,
      customQuality: this.customQuality,
      customQualityActive: this.customQualityActive,
      customFps: this.customFps,
      adaptiveFps: this.adaptiveFps,
      codec: this.preferredCodec as CodecName,
      fitMode: this.fitMode,
      showRemoteCursor: this.showRemoteCursor,
      followRemoteCursor: this.followRemoteCursor,
      followRemoteWindow: this.followRemoteWindow,
      cursorScale: this.cursorScale,
      clipboard: this.clipboardEnabled,
      remoteAudio: this.remoteAudioEnabled,
      audioMuted: this.audioMuted,
      audioVolume: this.audioVolume,
      keyboardMode: this.keyboardMode,
      inputMode: this.inputModePref,
      extraKeys: this.xkeys.shown,
      haptics: loadPrefs().haptics,
      barPortrait: loadPrefs().barPortrait,
      barLandscape: loadPrefs().barLandscape,
      compactKeyboard: loadPrefs().compactKeyboard,
      hideSuggestions: loadPrefs().hideSuggestions,
    };
  }

  /** More menu section for finger input; only where the primary pointer is a finger. */
  private touchMenuHtml(): string {
    if (!coarsePointer()) return '';
    return (
      '<div class="rd-pop-sep"></div><div class="rd-pop-title">' + htl('input_mode') + '</div>' +
      this.menuItem(null, tl('touch'), this.inputMode === 'touch', 'input:touch') +
      this.menuItem(null, tl('trackpad'), this.inputMode === 'trackpad', 'input:trackpad') +
      this.menuItem(null, tl('pointer'), this.inputMode === 'pointer', 'input:pointer') +
      ('vibrate' in navigator ? this.menuItem(null, tl('vibrate_on_touch_actions'), loadPrefs().haptics, 'haptics') : '')
    );
  }

  /** Keycodes for Map mode, or null for legacy character input. */
  private keyboardTarget(): KeyTarget | null {
    return this.keyboardMode === 'map' ? mapKeyboardTarget(this.peerPlatform, this.peerVersion) : null;
  }

  private syncFullscreenButton(): void {
    const btn = this.el.btnFullscreen;
    if (!btn) return;
    const fs = !!document.fullscreenElement;
    const label = fs ? tl('exit_fullscreen') : tl('fullscreen');
    btn.innerHTML = iconHtml(fs ? 'fullscreenExit' : 'fullscreen');
    btn.title = label;
    btn.setAttribute('aria-label', label);
    btn.setAttribute('aria-pressed', String(fs));
  }

  private openKeysPop(anchor: HTMLElement): void {
    this.openPop(
      anchor,
      (pop) => {
        pop.innerHTML =
          '<div class="rd-pop-title">' + htl('send_remote') + '</div>' +
          this.menuItem('keyboard', 'Ctrl+Alt+Del') +
          this.menuItem('keyboard', tl('windows_key')) +
          this.menuItem('keyboard', 'PrintScreen') +
          this.menuItem('keyboard', 'Escape') +
          this.menuItem('keyboard', 'Tab');
        const acts: [string, () => void][] = [
          [tl('key_sent', { key: 'Ctrl+Alt+Del' }), () => this.post({ c: 'ctrlAltDel' })],
          [tl('key_sent', { key: tl('windows_key') }), () => this.pressControl(ControlKey.Meta)],
          [tl('key_sent', { key: 'PrintScreen' }), () => this.pressControl(ControlKey.Snapshot)],
          [tl('key_sent', { key: 'Escape' }), () => this.pressControl(ControlKey.Escape)],
          [tl('key_sent', { key: 'Tab' }), () => this.pressControl(ControlKey.Tab)],
        ];
        pop.querySelectorAll<HTMLButtonElement>('.rd-mi').forEach((b, i) => {
          b.addEventListener('click', () => {
            acts[i]![1]();
            this.toast(acts[i]![0]);
            this.closePop();
          });
        });
      },
      true,
    );
  }

  private openTypePop(anchor: HTMLElement): void {
    this.openPop(
      anchor,
      (pop) => {
        pop.classList.add('rd-pop-type');
        pop.innerHTML = `
          <div class="rd-pop-title">${htl('type_on_remote_device')}</div>
          <textarea id="rd-type-text" rows="4" placeholder="${htl('sent_as_keystrokes_works_where')}"></textarea>
          <div class="rd-pop-actions">
            <button type="button" class="rd-chip rd-chip-solid" id="rd-type-send">${iconHtml('send')}<span>${htl('send_keystrokes')}</span></button>
          </div>`;
        const ta = q<HTMLTextAreaElement>(pop, '#rd-type-text');
        q<HTMLButtonElement>(pop, '#rd-type-send').addEventListener('click', () => {
          const text = ta.value;
          if (!text) return;
          const latched = this.latchCtrl || this.latchAlt;
          for (const cmd of latched ? buildKeyPressCommands(text) : buildTypeCommands(text)) this.post(cmd);
          this.toast(tn('typed_chars', text.length));
          this.closePop();
        });
      },
      true,
    );
    // Focus inside the tap itself: iOS opens its keyboard for nothing later.
    this.pop?.querySelector<HTMLTextAreaElement>('#rd-type-text')?.focus();
  }

  // --- on-screen keyboard (phones, tablets) ----------------------------------

  private setupSoftKeyboard(): void {
    const sink = document.createElement('textarea');
    sink.id = 'rd-kbd-sink';
    for (const [k, v] of Object.entries(sinkAttributes(loadPrefs().hideSuggestions))) sink.setAttribute(k, v);
    sink.setAttribute('aria-label', tl('on_screen_keyboard'));
    sink.tabIndex = -1;
    this.el.root.appendChild(sink);
    this.kbdSink = sink;
    this.sinkKeys = createKeyHandler((c) => this.post(c), () => this.keyboardTarget());
    this.softKeys = new SoftKeyboardInput(sink, (a) => this.onSoftKey(a));
    sink.addEventListener('keydown', (e) => this.softKeys.keydown(e));
    sink.addEventListener('keyup', (e) => this.softKeys.keyup(e));
    sink.addEventListener('beforeinput', (e) => this.softKeys.beforeinput(e));
    sink.addEventListener('input', () => this.softKeys.input());
    sink.addEventListener('compositionstart', () => this.softKeys.compositionstart());
    sink.addEventListener('compositionend', () => this.softKeys.compositionend());
    sink.addEventListener('focus', () => this.syncSoftKeyboardButton());
    sink.addEventListener('blur', () => {
      this.softKeys.reset();
      this.sinkKeys.reset();
      this.syncSoftKeyboardButton();
    });
  }

  private softKeyboardFocused(): boolean {
    return !!this.kbdSink && document.activeElement === this.kbdSink;
  }

  /**
   * Keyboard button. Must run synchronously in the tap: iOS only opens its
   * keyboard for a focus() made inside a user gesture.
   */
  private toggleSoftKeyboard(): void {
    if (this.ckbd?.shown) {
      this.showCompactKeyboard(false);
      return;
    }
    if (this.orientation === 'landscape' && this.ckbd && loadPrefs().compactKeyboard) {
      if (this.softKeyboardFocused()) this.kbdSink.blur();
      this.showCompactKeyboard(true);
      return;
    }
    if (this.softKeyboardFocused()) {
      this.kbdSink.blur();
      // Android's back button hides the keyboard but leaves the field
      // focused: then the tap means "show it again", not "hide it".
      if (this.viewportState && !this.viewportState.keyboard) this.focusSoftKeyboard();
      return;
    }
    this.focusSoftKeyboard();
  }

  /** The compact in-page keyboard (landscape option): its space is handled like the phone keyboard's. */
  private showCompactKeyboard(on: boolean): void {
    const k = this.ckbd;
    if (!k || k.shown === on) return;
    k.show(on);
    if (on) this.el.root.dataset.ckbd = '1';
    else delete this.el.root.dataset.ckbd;
    this.syncSoftKeyboardButton();
    requestAnimationFrame(() => (on ? this.keyboardSpaceOpened(false) : this.keyboardSpaceClosed()));
  }

  /** Hide whichever keyboard is open (extra-keys bar button). */
  private hideKeyboards(): void {
    if (this.ckbd?.shown) this.showCompactKeyboard(false);
    if (this.softKeyboardFocused()) this.kbdSink.blur();
  }

  /** More sheet option. The keyboard reads the attributes when the field gains focus: refocus it. */
  private setHideSuggestions(hide: boolean): void {
    this.rememberPrefs({ hideSuggestions: hide });
    for (const [k, v] of Object.entries(sinkAttributes(hide))) this.kbdSink.setAttribute(k, v);
    if (this.softKeyboardFocused()) {
      this.kbdSink.blur();
      this.focusSoftKeyboard();
    }
  }

  private focusSoftKeyboard(): void {
    this.softKeys.reset();
    this.kbdSink.focus({ preventScroll: true });
    this.syncSoftKeyboardButton();
  }

  private syncSoftKeyboardButton(): void {
    const on = this.softKeyboardFocused() || !!this.ckbd?.shown;
    for (const b of this.el.root.querySelectorAll<HTMLButtonElement>('[data-kbd-toggle], #rd-btn-kbd')) {
      b.classList.toggle('rd-on', on);
      b.setAttribute('aria-pressed', String(on));
    }
  }

  private onSoftKey(a: SoftKeyAction): void {
    switch (a.k) {
      case 'hardware':
        this.sinkKeys.onKey(a.event, a.down);
        return;
      case 'key': {
        const mods = this.xkeys.activeMods();
        if (mods.length) {
          // Shift+Enter, Ctrl+Backspace...: a real key with the sticky modifiers.
          const code = a.key === 'Enter' ? 'Enter' : a.key;
          const all = a.ctrl && !mods.includes('ctrl') ? [...mods, 'ctrl' as const] : mods;
          for (const cmd of keyComboCommands({ code, key: code }, all, this.keyboardTarget())) this.post(cmd);
          this.xkeys.consume();
          return;
        }
        this.post({
          c: 'key', down: false, press: true, keyKind: 'control',
          value: SOFT_KEY_CONTROL[a.key], modifiers: a.ctrl ? [ControlKey.Control] : [],
        });
        return;
      }
      case 'text': {
        const mods = this.xkeys.activeMods();
        if (mods.length) {
          // Sticky Ctrl/Alt/Win from the extra-keys bar: letters become shortcuts.
          for (const cmd of stickyTextCommands(a.text, mods, this.keyboardTarget())) this.post(cmd);
          if (mods.some((m) => m !== 'shift')) this.xkeys.consume();
        } else if (this.latchCtrl || this.latchAlt) {
          // Latched Ctrl/Alt turn letters into shortcuts: those need keys, not text.
          for (const cmd of buildKeyPressCommands(a.text)) this.post(cmd);
        } else {
          this.post({ c: 'text', text: a.text });
        }
        return;
      }
    }
  }

  // --- extra-keys bar (phones, tablets) ----------------------------------------

  private setupExtraKeys(): void {
    this.xkeys = new ExtraKeysBar({
      send: (cmds) => {
        for (const cmd of cmds) this.post(cmd);
      },
      target: () => this.keyboardTarget(),
      onHideKeyboard: () => this.hideKeyboards(),
    });
    this.el.root.insertBefore(this.xkeys.el, this.el.dock);
    if (coarsePointer() && loadPrefs().extraKeys) this.xkeys.show(true);
    this.syncExtraKeysButton();
  }

  private toggleExtraKeys(): void {
    const on = !this.xkeys.shown;
    this.xkeys.show(on);
    if (!on) this.xkeys.clearLatches();
    this.rememberPrefs({ extraKeys: on });
    this.syncExtraKeysButton();
  }

  private syncExtraKeysButton(): void {
    const on = this.xkeys.shown;
    for (const b of this.el.root.querySelectorAll<HTMLButtonElement>('[data-xkeys-toggle], #rd-btn-xkeys')) {
      b.classList.toggle('rd-on', on);
      b.setAttribute('aria-pressed', String(on));
    }
  }

  private onViewportChange(s: ViewportState): void {
    const wasOpen = this.viewportState?.keyboard ?? false;
    this.viewportState = s;
    this.syncOrientation();
    if (s.keyboard && !wasOpen) {
      this.keyboardSpaceOpened(true);
    } else if (!s.keyboard && wasOpen) {
      this.keyboardSpaceClosed();
    } else {
      this.updateView();
    }
  }

  /**
   * A keyboard (the phone's or the compact one) took the bottom of the
   * screen. Portrait: the remote screen keeps its full size and slides up,
   * so the point being worked on sits above the keyboard. Landscape: what is
   * left is a wide, short strip; the picture is fitted into it and zoomed to
   * its width around that point, instead of a postage stamp.
   */
  private keyboardSpaceOpened(systemKeyboard: boolean): void {
    if (!this.viewBeforeKeyboard) this.viewBeforeKeyboard = { ...this.view.view };
    const landscape = this.orientation === 'landscape';
    if (systemKeyboard && !landscape && this.fullSize) {
      this.frozenSize = this.fullSize;
      for (const el of [this.canvas, this.videoEl]) {
        el.style.width = `${this.frozenSize.w}px`;
        el.style.height = `${this.frozenSize.h}px`;
      }
    }
    this.updateView();
    if (landscape) this.view.fillWidth();
    const p = this.keyboardFocusPoint();
    if (p) this.view.ensureVisible(p.x, p.y, landscape ? 0.5 : 1 / 3);
    this.applyView();
  }

  private keyboardSpaceClosed(): void {
    this.frozenSize = undefined;
    for (const el of [this.canvas, this.videoEl]) {
      el.style.width = '';
      el.style.height = '';
    }
    this.updateView();
    if (this.viewBeforeKeyboard) {
      this.view.restore(this.viewBeforeKeyboard);
      this.viewBeforeKeyboard = undefined;
      this.applyView();
    }
  }

  /**
   * What to keep visible when a keyboard opens, element-local: the trackpad
   * cursor, else the last touch. Kept as a fraction of the remote image, as
   * the element itself changes size when the keyboard fits it into a strip.
   */
  private keyboardFocusPoint(): Pt | undefined {
    let f = this.focusFrac;
    if (this.inputMode === 'trackpad' && this.trackpad) {
      const c = this.trackpad.position();
      f = this.clientToFrac(c.x, c.y);
    }
    if (!f) return undefined;
    const r = this.view.contentRect;
    return { x: r.x + f.x * r.width, y: r.y + f.y * r.height };
  }

  /** Client point -> fraction of the remote image. */
  private clientToFrac(x: number, y: number): Pt | undefined {
    const c = this.contentClientRect();
    if (c.width <= 0 || c.height <= 0) return undefined;
    return { x: (x - c.x) / c.width, y: (y - c.y) / c.height };
  }

  /**
   * iPhone Safari has no fullscreen: once per browser, point at Add to Home
   * Screen, which opens the client full screen with no browser bars.
   */
  private maybeShowHomeScreenHint(): void {
    if (!shouldOfferHomeScreen(navigator as Navigator & { standalone?: boolean }, document.fullscreenEnabled === true)) return;
    try {
      if (localStorage.getItem(HOME_SCREEN_HINT_KEY)) return;
      localStorage.setItem(HOME_SCREEN_HINT_KEY, '1');
    } catch {
      return; // storage blocked: better never than on every session
    }
    this.toast(tl('add_to_home_screen_hint'), true);
    this.toastTimer = setTimeout(() => this.hideToast(), 9000); // longer than a normal toast
  }

  // --- docked controls (phones, tablets) ------------------------------------------

  private setupMobileBar(): void {
    this.el.root.classList.add('rd-mobile');
    const items = [
      { id: 'kbd', icon: 'keyboard', label: tl('show_hide_on_screen_keyboard'), attrs: 'data-kbd-toggle aria-pressed="false"', onClick: () => this.toggleSoftKeyboard() },
      { id: 'xkeys', icon: 'keyCombo', label: tl('extra_keys'), attrs: 'data-xkeys-toggle aria-pressed="false"', onClick: () => this.toggleExtraKeys() },
      { id: 'mode', icon: this.inputModeIcon(), label: tl('touch_or_trackpad'), onClick: () => this.cycleTouchMode() },
      { id: 'zoom', icon: 'zoom', label: tl('fit_or_actual_size'), attrs: 'aria-pressed="false"', onClick: () => this.toggleZoom() },
      { id: 'fullscreen', icon: 'fullscreen', label: tl('fullscreen'), attrs: 'aria-pressed="false"', onClick: () => this.barFullscreen() },
      // Only with more than one monitor (syncBar).
      { id: 'monitors', icon: 'monitor', label: tl('select_monitor'), attrs: 'aria-haspopup="true"', onClick: (b: HTMLButtonElement) => this.openMonitorPop(b) },
      { id: 'more', icon: 'more', label: tl('more_options'), attrs: 'aria-haspopup="true"', pinned: true, onClick: (b: HTMLButtonElement) => this.openMoreSheet(b) },
      { id: 'disconnect', icon: 'power', label: tl('disconnect'), pinned: true, onClick: () => this.disconnectByUser() },
    ] satisfies import('./mobile-bar').BarItem[];
    this.bar = new MobileBar(items, tl('session_controls'));
    this.el.root.appendChild(this.bar.el);
    this.ckbd = new CompactKeyboard(
      (a) => (a.k === 'hide' ? this.showCompactKeyboard(false) : this.onSoftKey(a)),
      tl('compact_keyboard'),
      tl('hide_keyboard'),
    );
    this.el.root.insertBefore(this.ckbd.el, this.el.dock);
    this.syncOrientation();
    this.syncBar();
    document.addEventListener('fullscreenchange', () => this.syncBar());
    const onRotate = (): void => this.syncOrientation();
    screen.orientation?.addEventListener?.('change', onRotate);
    window.addEventListener('orientationchange', onRotate);
    window.addEventListener('resize', onRotate);
    // Remember where the remote screen was last touched (keyboard avoidance).
    this.el.viewport.addEventListener('pointerdown', (e) => {
      if (e.target === this.canvas || e.target === this.videoEl) this.focusFrac = this.clientToFrac(e.clientX, e.clientY);
    }, true);
  }

  /** Dock the bar to the remembered edge for the way the device is held. */
  private syncOrientation(): void {
    if (!this.bar) return;
    const legacy = (window as unknown as { orientation?: number }).orientation;
    this.orientation = currentOrientation(screen.orientation?.type, legacy, window.innerWidth, window.innerHeight);
    const side = barSide(this.orientation, loadPrefs());
    this.el.root.dataset.orient = this.orientation;
    if (this.orientation === 'portrait' && this.ckbd?.shown) this.showCompactKeyboard(false);
    if (this.el.root.dataset.bar !== side) {
      this.el.root.dataset.bar = side;
      this.closePop();
    }
  }

  private swapBarSide(): void {
    this.rememberPrefs(swappedPrefs(this.orientation, loadPrefs()));
    this.syncOrientation();
  }

  /** Show only what applies now (monitors), and the current mode's icon and toggles. */
  private syncBar(): void {
    const bar = this.bar;
    if (!bar) return;
    const monitors = bar.button('monitors');
    if (monitors) monitors.hidden = this.displays.length < 2;
    bar.setIcon('mode', this.inputModeIcon());
    bar.setOn('zoom', this.view.zoomed);
    const fs = bar.button('fullscreen');
    if (fs) {
      fs.hidden = this.fullscreenMode() === 'hidden';
      const on = !!document.fullscreenElement;
      bar.setIcon('fullscreen', on ? 'fullscreenExit' : 'fullscreen');
      bar.setOn('fullscreen', on);
      const label = on ? tl('exit_fullscreen') : tl('fullscreen');
      fs.title = label;
      fs.setAttribute('aria-label', label);
    }
    this.syncSoftKeyboardButton();
    this.syncExtraKeysButton();
  }

  private inputModeIcon(): IconName {
    return this.inputMode === 'trackpad' ? 'trackpad' : this.inputMode === 'touch' ? 'touch' : 'pointer';
  }

  private fullscreenMode(): 'toggle' | 'hint' | 'hidden' {
    const standalone = (navigator as Navigator & { standalone?: boolean }).standalone === true ||
      (typeof matchMedia === 'function' && matchMedia('(display-mode: standalone)').matches);
    return fullscreenButtonMode(document.fullscreenEnabled === true, standalone);
  }

  /** Bar Fullscreen button (see fullscreenButtonMode). */
  private barFullscreen(): void {
    if (this.fullscreenMode() === 'toggle') {
      void this.toggleFullscreen();
      return;
    }
    this.toast(tl('add_to_home_screen_hint'), true);
    this.toastTimer = setTimeout(() => this.hideToast(), 9000);
  }

  /** Mode button: Touch <-> Trackpad (Pointer lives in the More sheet). */
  private cycleTouchMode(): void {
    const next: InputMode = this.inputMode === 'touch' ? 'trackpad' : 'touch';
    this.chooseInputMode(next);
    this.toast(next === 'trackpad' ? tl('trackpad_mode_move_cursor') : tl('touch_mode_tap_drag_scroll'));
  }

  /** Zoom button: Fit <-> Actual size (1:1). */
  private toggleZoom(): void {
    const mode: FitMode = this.view.zoomed ? 'fit' : 'actual';
    this.setFitMode(mode);
    this.rememberPrefs({ fitMode: mode });
  }

  /**
   * More: everything that is not on the bar, as a sheet — from the bottom in
   * portrait, beside the bar in landscape. Tiles for actions, then the
   * options, then the full settings menu.
   */
  private openMoreSheet(anchor: HTMLElement): void {
    this.openPop(anchor, (pop) => {
      pop.classList.add('rd-sheet');
      const can = (perm: string): boolean => this.permissions[perm] !== false;
      const tiles: [string, IconName, string, boolean, boolean][] = [
        ['monitors', 'monitor', tl('select_monitor'), !this.el.btnMonitors.hidden, false],
        ['clipboard', 'clipboard', tl('send_clipboard'), can('Clipboard') && remoteInputAllowed(this.viewOnly, 'clipboard'), false],
        ['files', 'folderTransfer', tl('file_transfer_2'), can('File'), false],
        ['chat', 'chat', tl('chat'), true, false],
        ['details', 'info', tl('session_details'), true, false],
        ['viewonly', 'eye', tl('view_only'), true, this.viewOnly],
        ['swap', 'swap', tl('swap_side'), true, false],
      ];
      const prefs = loadPrefs();
      pop.innerHTML =
        '<div class="rd-sheet-grid">' +
        tiles
          .filter(([, , , show]) => show)
          .map(([id, icon, label, , on]) =>
            `<button type="button" class="rd-sheet-tile${on ? ' rd-on' : ''}" data-tile="${id}" title="${escapeHtml(label)}" aria-pressed="${on}">` +
            `${iconHtml(icon)}<span>${escapeHtml(label)}</span></button>`,
          )
          .join('') +
        '</div><div class="rd-pop-sep"></div>' +
        this.menuItem('pointer', tl('pointer'), this.inputMode === 'pointer', 'opt:pointer') +
        this.menuItem(null, tl('hide_suggestions'), prefs.hideSuggestions, 'opt:suggestions') +
        this.menuItem(null, tl('compact_keyboard_landscape'), prefs.compactKeyboard, 'opt:compactKbd') +
        ('vibrate' in navigator ? this.menuItem(null, tl('vibrate_on_touch_actions'), prefs.haptics, 'opt:haptics') : '') +
        '<div class="rd-pop-sep"></div>' +
        this.menuItem('more', tl('more_options'), false, 'opt:settings');
      const act: Record<string, () => void> = {
        monitors: () => this.openMonitorPop(anchor),
        clipboard: () => void this.sendClipboard(),
        files: () => this.openSide('files'),
        chat: () => this.openSide('chat'),
        details: () => this.openSide('details'),
        viewonly: () => this.toggleViewOnly(),
        swap: () => this.swapBarSide(),
        'opt:pointer': () => this.chooseInputMode(this.inputMode === 'pointer' ? 'touch' : 'pointer'),
        'opt:suggestions': () => this.setHideSuggestions(!loadPrefs().hideSuggestions),
        'opt:compactKbd': () => {
          const on = !loadPrefs().compactKeyboard;
          this.rememberPrefs({ compactKeyboard: on });
          if (!on) this.showCompactKeyboard(false);
        },
        'opt:haptics': () => {
          const on = !loadPrefs().haptics;
          setHapticsEnabled(on);
          this.rememberPrefs({ haptics: on });
          haptic();
        },
        'opt:settings': () => this.openMorePop(anchor),
      };
      for (const b of pop.querySelectorAll<HTMLButtonElement>('[data-tile], [data-action^="opt:"]')) {
        b.addEventListener('click', () => {
          const id = b.dataset.tile ?? b.dataset.action!;
          this.closePop(); // follow-up popovers anchor on the same button
          act[id]?.();
        });
      }
    });
    // A sheet, not an anchored popover: the stylesheet places it.
    const pop = this.pop;
    if (pop?.classList.contains('rd-sheet')) {
      pop.dataset.sheet = this.orientation === 'landscape' ? (this.el.root.dataset.bar === 'left' ? 'left' : 'right') : (this.el.root.dataset.bar === 'top' ? 'top' : 'bottom');
      pop.style.left = pop.style.top = pop.style.maxHeight = '';
    }
  }


  // --- connect overlay ------------------------------------------------------------

  private renderOverlay(): void {
    Object.assign(this.el, renderConnectCard(this.el.overlay, {
      tagline: `${htl('overlay_title')} ${overlayVersion(this.cfg)}`,
    }));
    this.el.connectBtn.addEventListener('click', () => this.onConnectClick());
    this.el.reconnectCancel.addEventListener('click', () => this.cancelRestartReconnect());
    const enter = (e: KeyboardEvent): void => {
      if (e.key === 'Enter') this.onConnectClick();
    };
    this.el.passwordInput.addEventListener('keydown', enter);
    this.el.peerIdInput.addEventListener('keydown', enter);
    this.el.twoFactorBtn.addEventListener('click', () => this.submitTwoFactor());
    this.el.twoFactorInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') this.submitTwoFactor();
    });
  }

  /** The device asked for its 2FA code; the connection waits for it. */
  private onTwoFactor(wrong: boolean): void {
    this.showOverlay();
    this.setOverlayBusy(false);
    showTwoFactor(this.el, true, !!this.fixedPeerId);
    this.el.overlayStatus.hidden = true;
    this.setOverlayError(wrong ? tl('wrong_2fa_code') : null);
    this.el.twoFactorInput.focus();
  }

  private submitTwoFactor(): void {
    const code = consumeTwoFactorCode(this.el.twoFactorInput);
    if (!code) {
      this.setOverlayError(tl('enter_2fa_code'));
      return;
    }
    if (!this.post({ c: 'auth2fa', code })) return;
    this.setOverlayBusy(true);
    this.setOverlayStatusText(`${STATE_LABEL.login}…`);
  }

  private hideTwoFactor(): void {
    if (this.el) showTwoFactor(this.el, false, !!this.fixedPeerId);
    this.syncShareCard();
  }

  // --- session lifecycle -----------------------------------------------------

  // Reflect any stored credential for this device: tick the box and show a saved
  // placeholder instead of an empty field. A real value never leaves storage.
  private hydrateSavedPassword(peerId: string): void {
    const has = !!peerId && loadSavedHash(peerId) !== null;
    this.el.saveCheckbox.checked = has;
    this.el.passwordInput.value = '';
    this.el.passwordInput.placeholder = has
      ? tl('saved_password_click_change')
      : !this.addressBookRefused && addressBookReady(this.cfg, peerId)
        ? tl('address_book_password_ready')
        : tl('enter_password');
  }

  /**
   * Why the browser will refuse to run this page's session, or null if it won't.
   *
   * Two things used to make an insecure origin fatal: `crypto.subtle` for the
   * login hash, and WebCodecs' `VideoDecoder` for video. The hash no longer
   * uses Web Crypto (see core/sha256.ts), and video falls back to Media Source
   * Extensions, which is not secure-context gated. So plain http:// now works
   * where MSE can play H.264 — degraded, and the operator is told so.
   *
   * What remains fatal is an origin with neither WebCodecs nor MSE H.264: there
   * is no third way to show the remote screen. Saying so plainly beats the old
   * failure, `Cannot read properties of undefined (reading 'digest')`, which
   * sent operators hunting through their config (#3).
   */
  private secureContextProblem(): string | null {
    if (typeof VideoDecoder !== 'undefined') return null; // full-quality path
    if (mseH264Available()) return null; // degraded path — see fallbackNotice()

    if (typeof isSecureContext !== 'undefined' && !isSecureContext) {
      return tl('secure_context_error');
    }
    return tl('no_decoder_error');
  }

  private consumePasswordInput(): string {
    const password = this.el.passwordInput.value;
    this.el.passwordInput.value = '';
    return password;
  }

  private onConnectClick(): void {
    if (this.worker && this.state !== 'error' && this.state !== 'closed') return;
    if (this.shareEnded) {
      this.setOverlayError(tl('share_ended'));
      return;
    }
    const peerId = normalizePeerId(this.el.peerIdInput.value || this.fixedPeerId);
    if (!peerId) {
      this.setOverlayError(tl('enter_device_id'));
      return;
    }
    if (!this.cfg) {
      this.setOverlayError('Missing window.__RD__ configuration');
      return;
    }
    const blocked = this.secureContextProblem();
    if (blocked) {
      this.setOverlayError(blocked);
      return;
    }
    this.peerId = peerId;
    this.setOverlayError(null);
    this.setLoggedOutFlag(false); // connecting again clears the logout marker

    const typed = this.consumePasswordInput();
    // A share viewer always goes through the accept window: the page shares
    // its origin with the console's web client, so a password saved there for
    // this device is neither used nor cleared.
    const saved = this.share ? null : loadSavedHash(peerId);
    // If the user left the field blank and we have a stored hash, reuse it.
    // If the "save" box is off, forget any stored credential for this device.
    if (!this.share && !this.el.saveCheckbox.checked) clearSavedHash(peerId);
    this.pendingHashHex = undefined;
    this.connectedWithSavedHash = false;
    this.connectedWithAddressBook = false;

    let config: SessionConfig;
    if (!typed && saved) {
      this.connectedWithSavedHash = true;
      config = buildSessionConfig(this.cfg, peerId, '', saved);
    } else {
      config = buildSessionConfig(this.cfg, peerId, typed, undefined, undefined, !this.addressBookRefused);
    }
    this.startSession({ ...config, sessionId: newSessionId() });
  }

  private beginRemoteRestart(): void {
    if (this.state !== 'streaming' || !this.reconnectConfig) {
      this.toast(tl('restart_is_unavailable_until_session'));
      return;
    }
    if (!window.confirm(tl('restart_remote_device_and_reconnect'))) return;

    const config: SessionConfig = {
      ...this.reconnectConfig,
      password: '',
      savedHashHex: this.sessionHashHex ?? this.reconnectConfig.savedHashHex,
    };
    this.clearRestartFlow();
    this.el.reconnectCancel.hidden = false;
    this.post({ c: 'restartRemoteDevice' });
    const flow: RestartFlow = { kind: 'restart', startedAt: Date.now(), attempt: 0, config, reconnecting: false };
    flow.deadlineTimer = setTimeout(() => this.expireRestartFlow(flow), RESTART_RECONNECT_TIMEOUT_MS);
    this.restartFlow = flow;
    this.toast(tl('restart_command_sent_waiting_for'), true);
  }

  private scheduleRestartReconnect(detail?: string): void {
    const flow = this.restartFlow;
    if (!flow || flow.timer) return;
    clearTimeout(flow.stableTimer);
    flow.stableTimer = undefined;
    this.teardown();
    this.clearSecurityState();
    this.filePanel?.destroy();
    this.filePanel = undefined;
    this.closeSide();
    this.closePop();

    const elapsed = Date.now() - flow.startedAt;
    const delay = flow.kind === 'drop'
      ? nextReconnectDelay(flow.attempt, elapsed)
      : nextRestartReconnectDelay(flow.attempt, elapsed);
    if (delay === null) {
      this.clearRestartFlow();
      const why = flow.kind === 'drop' ? tl('could_not_reconnect') : tl('restart_no_return');
      this.setState('error', why + (detail ? ` — ${detail}` : ''));
      return;
    }

    flow.attempt += 1;
    this.state = 'connecting';
    this.el.root.dataset.state = 'connecting';
    this.showOverlay();
    this.setOverlayBusy(true);
    this.el.reconnectCancel.hidden = false;
    const wait = { attempt: flow.attempt, seconds: Math.ceil(delay / 1000) };
    this.setOverlayStatusText(flow.kind === 'drop' ? tl('connection_lost_reconnecting', wait) : tl('waiting_restart_retry', wait));
    flow.timer = setTimeout(() => {
      if (this.restartFlow !== flow) return;
      flow.timer = undefined;
      if (Date.now() - flow.startedAt >= (flow.kind === 'drop' ? DROP_RECONNECT_TIMEOUT_MS : RESTART_RECONNECT_TIMEOUT_MS)) {
        this.expireRestartFlow(flow);
        return;
      }
      flow.reconnecting = true;
      this.startSession({ ...flow.config, password: '' });
    }, delay);
  }

  /**
   * The connection died by itself (core/reconnect.ts): reconnect with the
   * same credentials (the session's h1, or the address book again), keeping
   * the zoom, input mode and keyboard, until it works or five minutes pass.
   */
  private beginDropReconnect(detail?: string): void {
    const base = this.reconnectConfig!;
    const flow: RestartFlow = {
      kind: 'drop',
      startedAt: Date.now(),
      attempt: 0,
      config: { ...base, password: '', savedHashHex: this.sessionHashHex ?? base.savedHashHex },
      reconnecting: false,
    };
    this.clearRestartFlow();
    this.viewBeforeReconnect = { ...this.view.view };
    this.keyboardBeforeReconnect = this.softKeyboardFocused();
    flow.deadlineTimer = setTimeout(() => this.expireRestartFlow(flow), DROP_RECONNECT_TIMEOUT_MS);
    this.restartFlow = flow;
    this.dbg('reconnect', { detail });
    this.scheduleRestartReconnect(detail);
  }

  private cancelRestartReconnect(): void {
    const wasWaiting = this.state !== 'streaming';
    if (!this.restartFlow) return;
    this.clearRestartFlow();
    if (wasWaiting) this.setState('closed');
    this.toast(tl('automatic_reconnect_cancelled'));
  }

  private expireRestartFlow(flow: RestartFlow): void {
    if (this.restartFlow !== flow) return;
    const sessionStillStreaming = this.state === 'streaming';
    const reconnecting = flow.reconnecting;
    this.clearRestartFlow();
    if (reconnecting) {
      this.teardown(true);
      this.clearSecurityState();
      this.setState('error', flow.kind === 'drop' ? tl('could_not_reconnect') : tl('remote_device_did_not_return'));
    } else if (sessionStillStreaming) {
      this.toast(tl('no_remote_restart_was_detected'));
    } else {
      this.setState('error', tl('remote_device_did_not_return'));
    }
  }

  private clearRestartFlow(): void {
    if (this.restartFlow) {
      clearTimeout(this.restartFlow.timer);
      clearTimeout(this.restartFlow.stableTimer);
      clearTimeout(this.restartFlow.deadlineTimer);
    }
    this.restartFlow = undefined;
    this.viewBeforeReconnect = undefined;
    if (this.el?.reconnectCancel) this.el.reconnectCancel.hidden = true;
  }

  private startSession(config: SessionConfig): void {
    this.userClosing = false;
    this.teardown();
    // Retain only the challenge-independent password hash for reconnects. The
    // typed plaintext is transferred to the worker and never kept in UI state.
    this.reconnectConfig = { ...config, password: '' };
    // A fresh connection may be a different peer/credential — retire the panel
    // and everything else that belonged to the previous session.
    this.filePanel?.destroy();
    this.filePanel = undefined;
    this.closeSide();
    this.closePop();
    this.chatLog = [];
    this.chatUnread = 0;
    this.renderChatBadges();
    this.viewOnly = false;
    this.el.btnViewOnly.classList.remove('rd-on');
    this.el.btnViewOnly.setAttribute('aria-pressed', 'false');
    this.setLatches(false, false);
    this.clearSecurityState();
    this.peerWho = '';
    this.peerPlatform = '';
    this.peerVersion = '';
    this.terminalSupported = false;
    this.cameraSupported = false;
    this.platformAdditions = '';
    this.codecSupport = ['auto'];
    this.adaptiveStableSamples = 0;
    this.lastDroppedFrames = 0;
    this.el.remoteCursor.hidden = true;
    this.sessionHashHex = config.savedHashHex;
    this.stats = undefined;
    this.streamStartMs = 0;
    this.displays = [];
    this.current = 0;
    this.audioStarted = false;
    // Remembered display and media settings, read fresh so a reconnect picks
    // up changes made during the previous session. The peer gets the same
    // values in the LoginRequest, so the menus and the stream agree.
    const prefs = loadPrefs();
    this.applyPrefs(prefs);
    config = withRememberedOptions(config, prefs);
    this.removeClipboardSyncOffer();
    this.createAudioPlayback();
    const canvas = this.freshCanvas();
    this.trackpad?.reset();
    this.trackpad = this.trackpadOut = undefined;
    this.view.reset();
    this.applyView();
    const offscreen = canvas.transferControlToOffscreen();
    const worker = new Worker(this.workerUrl, { type: 'module' });
    this.worker = worker;
    const rtc = webRtcFor(worker);
    this.rtc = rtc;
    worker.onmessage = (e: MessageEvent<UiWorkerEvent>) => {
      if (!isRtcEvent(rtc, e.data)) this.onEvent(e.data);
    };
    worker.onerror = (e: ErrorEvent) => this.setState('error', e.message || 'session worker failed');
    const cmd: UiCommand = { c: 'connect', config: { ...config, messages: (window as unknown as { __RD__?: { messages?: Record<string, string> } }).__RD__?.messages }, canvas: offscreen };
    worker.postMessage(cmd, [offscreen]);
    this.detach = attachInput(canvas, (c) => this.post(c), () => this.currentRect(), this.inputOptions());
    const shown = this.share ? this.share.deviceName || this.share.label : this.peerId;
    this.el.peerLabel.textContent = shown;
    this.el.statDevice.textContent = shown;
    this.el.statTransport.textContent = '—';
    this.resetPermissions();
    this.setState('connecting');
  }

  // A canvas can be transferred to OffscreenCanvas only once; reconnects need a fresh node.
  private freshCanvas(): HTMLCanvasElement {
    if (this.canvasTransferred) {
      const fresh = this.canvas.cloneNode(false) as HTMLCanvasElement;
      this.canvas.replaceWith(fresh);
      this.canvas = fresh;
    }
    this.canvasTransferred = true;
    return this.canvas;
  }

  private teardown(immediateWorkerTermination = false): void {
    this.sessionEpoch += 1;
    this.endVoiceCall(false);
    this.releaseRemoteSecurityState();
    if (this.recording && this.permissions.Recording !== false) {
      this.post({ c: 'clientRecording', recording: false });
    }
    this.recording = false;
    this.recordingStartedMs = 0;
    this.el.recordingIndicator.hidden = true;
    this.recorder?.close();
    this.recorder = undefined;
    this.audioPlayback?.close();
    this.audioPlayback = undefined;
    this.removeClipboardSyncOffer();
    this.detach?.();
    this.detach = undefined;
    this.teardownMse();
    const w = this.worker;
    this.worker = undefined;
    this.rtc?.close();
    this.rtc = undefined;
    if (w) {
      w.onmessage = null;
      w.onerror = null;
      if (immediateWorkerTermination) w.terminate();
      else setTimeout(() => w.terminate(), 250); // let a pending 'disconnect' flush first
    }
    this.resetPermissions();
  }

  /**
   * Single choke point to the worker. View-only swallows everything that would
   * act on the remote device. The Ctrl/Alt latches merge into the modifiers of
   * key and mouse traffic — a pure merge, no synthetic key down/up, so a
   * dropped session can never leave a modifier stuck on the peer.
   */
  /**
   * Diagnostic log, off unless ?debug=1 or window.__rdDebug is set.
   *
   * Read live rather than cached at mount so the flag can be flipped mid
   * session from the console — the interesting failures only exist once a
   * session is running, and a reload throws them away.
   */
  private dbg(tag: string, data: unknown): void {
    if (!debugEnabled(location.search, window)) return;
    console.log(`[rd:${tag}]`, data);
  }

  /** Throttle for the per-event input log, which would otherwise flood. */
  private lastDbgMouseMs = 0;

  /** Returns true when the command reached the worker. */
  private post(cmd: UiCommand): boolean {
    // Lock screen is a one-shot control key: the peer handles it whether or
    // not a display is online, and latched Ctrl/Alt must not ride along.
    const lockScreen = cmd.c === 'key' && cmd.keyKind === 'control' && cmd.value === ControlKey.LockScreen;
    const inputChannel: RemoteInputChannel | null = cmd.c === 'mouse'
      ? 'pointer'
      : cmd.c === 'key' || cmd.c === 'ctrlAltDel' || cmd.c === 'text'
        ? 'keyboard'
        : cmd.c === 'clipboardText'
          ? 'clipboard'
          : null;
    const sendsRemoteInput = cmd.c === 'mouse' || cmd.c === 'key' || cmd.c === 'ctrlAltDel' || cmd.c === 'text';
    if (sendsRemoteInput && !lockScreen && this.displays[this.current]?.online !== true) return false;
    if (cmd.c === 'mouse') {
      const now = Date.now();
      if (now - this.lastDbgMouseMs > 1000) {
        this.lastDbgMouseMs = now;
        // The whole question in one line: the coordinate actually leaving the
        // client, the display index it was mapped against, and that display's
        // origin. If x/y sit inside display 0 while current is 1, the mapping
        // is using the wrong rect; if current is still 0, the switch never
        // reached us.
        this.dbg('mouse', {
          sent: { x: cmd.x, y: cmd.y },
          current: this.current,
          rect: this.currentRect(),
          displays: this.displays.map((d) => ({ x: d.x, y: d.y, w: d.width, h: d.height })),
        });
      }
    }
    if (inputChannel && !remoteInputAllowed(this.viewOnly, inputChannel)) return false;
    if ((this.latchCtrl || this.latchAlt) && !lockScreen && (cmd.c === 'mouse' || cmd.c === 'key')) {
      const extra: number[] = [];
      if (this.latchCtrl) extra.push(ControlKey.Control);
      if (this.latchAlt) extra.push(ControlKey.Alt);
      cmd = { ...cmd, modifiers: [...new Set([...cmd.modifiers, ...extra])] };
    }
    const sticky = cmd.c === 'mouse' ? this.xkeys?.activeMods() ?? [] : [];
    if (sticky.length && cmd.c === 'mouse') {
      cmd = { ...cmd, modifiers: [...new Set([...cmd.modifiers, ...modControlKeys(sticky)])] };
    }
    if (!this.worker) return false;
    this.worker.postMessage(cmd);
    // Ctrl+click, Shift+click: a one-shot modifier is spent when the button comes up.
    if (sticky.length && cmd.c === 'mouse' && (cmd.mask & 7) === 2) this.xkeys.consume();
    return true;
  }

  // --- local zoom / pan, trackpad cursor --------------------------------------

  /** The element showing the remote screen (canvas, or the MSE <video> fallback). */
  private surface(): HTMLElement {
    return this.videoEl.hidden ? this.canvas : this.videoEl;
  }

  /** Re-measure after a resize, rotation, keyboard or display change; keeps the zoom. */
  private updateView(): void {
    const vp = this.el.viewport;
    const d = this.currentRect();
    if (!vp.clientWidth || !vp.clientHeight || !d.width || !d.height) return;
    if (!this.viewportState?.keyboard) {
      const last = this.fullSize;
      // A shrinking height at the same width is a keyboard on its way in
      // (Android resizes before the visual viewport reports it): keep the old one.
      if (!last || last.w !== vp.clientWidth || vp.clientHeight >= last.h) {
        this.fullSize = { w: vp.clientWidth, h: vp.clientHeight };
      }
    }
    const full = this.frozenSize ?? { w: vp.clientWidth, h: vp.clientHeight };
    this.view.setGeometry(full.w, full.h, d.width / d.height, vp.clientWidth, vp.clientHeight);
    this.view.allowZoom(this.view.oneToOneScale(d.width));
    this.applyView();
  }

  /** New session or display: back to Fit (or 1:1 if that is the remembered choice). */
  private resetView(): void {
    const keep = this.restartFlow?.kind === 'drop' ? this.viewBeforeReconnect : undefined;
    this.view.reset();
    this.updateView();
    if (keep) {
      this.view.restore(keep);
      this.applyView();
      return;
    }
    this.applyFitZoom();
  }

  private applyFitZoom(): void {
    if (!coarsePointer()) return;
    if (this.fitMode === 'actual') this.view.zoomTo(this.view.oneToOneScale(this.currentRect().width));
    else this.view.reset();
    this.applyView();
  }

  private applyView(): void {
    this.bar?.setOn('zoom', this.view.zoomed);
    const css = this.view.css();
    for (const el of [this.canvas, this.videoEl]) {
      el.style.transformOrigin = css ? '0 0' : '';
      el.style.transform = css;
    }
    if (this.tpCursor) this.drawTrackpadCursor();
  }

  /** Pinch: zoom about the fingers (client coordinates), then pan with them. */
  private zoomView(scale: number, center: Pt, pan: Pt): void {
    this.lastUserPanAt = Date.now();
    const vp = this.el.viewport.getBoundingClientRect();
    this.view.zoomAt(scale, center.x - vp.left, center.y - vp.top);
    this.view.panBy(pan.x, pan.y);
    this.applyView();
  }

  /** Where the remote image is on screen (client coordinates). */
  private contentClientRect(): Rect {
    const r = this.surface().getBoundingClientRect();
    const d = this.currentRect();
    const c = containRect(r.width, r.height, d.height ? d.width / d.height : 0);
    return { x: r.left + c.x, y: r.top + c.y, width: c.width, height: c.height };
  }

  private trackpadFor(out: TouchOutput): TrackpadMapper {
    if (!this.trackpad || this.trackpadOut !== out) {
      this.trackpad?.reset();
      this.trackpadOut = out;
      this.trackpad = new TrackpadMapper(out, {
        content: () => this.contentClientRect(),
        cursor: (p, byCursor) => this.onTrackpadCursor(p, byCursor),
        clampToView: (p) => this.clampToVisible(p),
      });
    }
    return this.trackpad;
  }

  /**
   * Trackpad cursor moved. Only a move of the cursor itself scrolls a zoomed
   * view, and only by the amount it went past the edge (no re-centring, so
   * no jumping back and forth); never during or right after the user's own
   * pinch / pan, which always wins.
   */
  private onTrackpadCursor(p: Pt, byCursor: boolean): void {
    if (byCursor && this.view.zoomed && Date.now() - this.lastUserPanAt > USER_PAN_HOLD_MS) {
      const vp = this.el.viewport.getBoundingClientRect();
      const v = this.view.view;
      const lx = (p.x - vp.left - v.tx) / v.scale;
      const ly = (p.y - vp.top - v.ty) / v.scale;
      if (this.view.keepInView(lx, ly, FOLLOW_MARGIN)) this.applyView();
    }
    this.drawTrackpadCursor(byCursor);
  }

  /**
   * An off-screen cursor (client coordinates) comes to just inside the visible
   * part of the remote image, at the follow margin so the next move does not
   * scroll back. An on-screen one is left alone: moves along the host's screen
   * edge (menu bar, taskbar) must not be pulled inwards.
   */
  private clampToVisible(p: Pt): Pt {
    const vp = this.el.viewport.getBoundingClientRect();
    const c = this.contentClientRect();
    return {
      x: intoSpan(p.x, Math.max(vp.left, c.x), Math.min(vp.right, c.x + c.width), FOLLOW_MARGIN),
      y: intoSpan(p.y, Math.max(vp.top, c.y), Math.min(vp.bottom, c.y + c.height), FOLLOW_MARGIN),
    };
  }

  private drawTrackpadCursor(moving = false): void {
    const on = this.inputMode === 'trackpad';
    this.tpCursor.hidden = !on;
    clearTimeout(this.tpCursorFade);
    this.tpCursor.classList.remove('rd-faded');
    if (!on) return;
    // Where the host draws its own cursor (in the video, or the remote-cursor
    // overlay), ours is only a pointer while moving: once still, it fades so
    // there are not two arrows side by side (the host's lags by the latency).
    const hostDrawsCursor = this.displays[this.current]?.cursorEmbedded === true || !this.el.remoteCursor.hidden;
    if (hostDrawsCursor) {
      this.tpCursorFade = setTimeout(() => this.tpCursor.classList.add('rd-faded'), moving ? 700 : 1500);
    }
    let p = this.trackpad?.position();
    if (!p) {
      const c = this.contentClientRect();
      p = { x: c.x + c.width / 2, y: c.y + c.height / 2 };
    }
    const vp = this.el.viewport.getBoundingClientRect();
    this.tpCursor.style.transform = `translate(${Math.round(p.x - vp.left)}px, ${Math.round(p.y - vp.top)}px)`;
  }

  /** Input wiring shared by the canvas and the MSE <video> surface. */
  private inputOptions(): InputOptions {
    return {
      isTouchMode: () => this.inputMode !== 'pointer',
      keyboardTarget: () => this.keyboardTarget(),
      focusTarget: () => (this.softKeyboardFocused() ? this.kbdSink : null),
      touch: {
        haptic: () => haptic(),
        keyboard: () => this.toggleSoftKeyboard(),
        zoom: (scale, center, pan) => this.zoomView(scale, center, pan),
        mapper: (out) => (this.inputMode === 'trackpad' ? this.trackpadFor(out) : null),
      },
    };
  }

  private currentRect(): DisplayRect {
    const d = this.displays[this.current];
    if (d) return displayToRect(d);
    if (this.stats?.width && this.stats.height) {
      return { x: 0, y: 0, width: this.stats.width, height: this.stats.height };
    }
    return { x: 0, y: 0, width: 1280, height: 720 };
  }

  // --- worker events ---------------------------------------------------------

  private onEvent(ev: UiWorkerEvent): void {
    switch (ev.t) {
      case 'state':
        if (this.restartFlow && ev.peerInitiated) {
          this.clearRestartFlow();
          this.setState(ev.state, ev.detail);
        } else if (this.restartFlow && (ev.state === 'error' || ev.state === 'closed')) {
          this.scheduleRestartReconnect(ev.detail);
        } else if (
          this.reconnectConfig &&
          shouldAutoReconnect(ev, { wasStreaming: this.state === 'streaming', userClosed: this.userClosing })
        ) {
          this.beginDropReconnect(ev.detail);
        } else {
          this.setState(ev.state, ev.detail);
        }
        break;
      case 'peerInfo': {
        this.dbg('peerInfo', { current: ev.current, displays: ev.displays });
        // Login: start at Fit; a later refresh (resolution change) keeps the zoom.
        const firstInfo = ev.current !== undefined;
        queueMicrotask(() => (firstInfo ? this.resetView() : this.updateView()));
        this.displays = ev.current === undefined
          ? mergeDisplayRefresh(this.displays, ev.displays, this.current)
          : ev.displays;
        if (ev.current !== undefined) this.current = ev.current;
        this.peerWho = ev.username ? `${ev.username}@${ev.hostname}` : ev.hostname;
        this.peerPlatform = ev.platform || '';
        this.peerVersion = ev.version || '';
        this.privacyModeSupported = ev.privacyModeSupported;
        this.privacyModeImpls = ev.privacyModeImpls;
        this.terminalSupported = ev.terminalSupported;
        this.cameraSupported = ev.viewCameraSupported;
        this.platformAdditions = mergePlatformAdditions(this.platformAdditions, ev.platformAdditions);
        if (!canUseRemoteCursor(this.peerPlatform, this.displays[this.current])) {
          this.el.remoteCursor.hidden = true;
        }
        this.el.peerLabel.textContent = this.peerWho || (this.share ? this.share.deviceName || this.share.label : this.peerId);
        this.refreshPeerSub();
        this.el.statVersion.textContent = ev.version || '—';
        this.el.statUser.textContent = this.peerWho || '—';
        this.el.statPlatform.textContent = this.peerPlatform || '—';
        const currentDisplay = this.displays[this.current];
        const hasDisplayControls = !!currentDisplay?.resolutions.length || !!currentDisplay?.originalResolution ||
          !!parseVirtualDisplayCapability(this.peerPlatform, this.platformAdditions);
        this.el.btnMonitors.hidden = this.displays.length < 2 && !hasDisplayControls;
        this.syncBar();
        document.title = `${this.peerId} — CortenDesk`;
        break;
      }
      case 'switchDisplay': {
        // Authoritative: the host telling us what it is now capturing. Trust
        // its geometry over the PeerInfo snapshot, which can be stale by the
        // time a switch happens (resolution changed, monitor re-arranged, a
        // display that was offline at login).
        this.dbg('switchDisplay', ev);
        this.current = ev.index;
        applySwitchDisplay(this.displays, ev);
        if (ev.cursorEmbedded) this.el.remoteCursor.hidden = true;
        // On the MSE fallback the muxer is built around the stream it was
        // started with, so a new frame size has to start a new one. The worker
        // holds the forwarded stream until the next key frame, which is what
        // rebuilds this on the following push.
        this.teardownMse();
        this.refreshPeerSub();
        this.resetView();
        break;
      }
      case 'followDisplay':
        if ((this.followRemoteWindow || this.followRemoteCursor) && ev.index !== this.current && this.displays[ev.index]?.online) {
          this.post({ c: 'switchDisplay', index: ev.index });
        }
        break;
      case 'codecSupport':
        this.dbg('codecSupport', ev.codecs);
        this.codecSupport = ev.codecs;
        if (!this.codecSupport.includes(this.preferredCodec as never)) this.preferredCodec = 'auto';
        break;
      case 'stats':
        this.onStats(ev.stats);
        break;
      case 'debug':
        this.dbg(ev.tag, ev.data);
        break;
      case 'transport':
        this.el.statTransport.textContent = tl(`transport_${ev.kind.replace('-', '_')}`);
        this.dbg('transport', ev.kind);
        break;
      case 'audioPcm':
        if (this.remoteAudioEnabled && this.permissions.Audio !== false) {
          this.audioPlayback?.enqueue(ev.pcm, ev.sampleRate, ev.channels);
        }
        break;
      case 'cursor': {
        const css = cursorCss(ev.pngDataUrl, ev.hotx, ev.hoty);
        this.canvas.style.cursor = css;
        this.videoEl.style.cursor = css;
        this.el.remoteCursor.src = ev.pngDataUrl;
        this.remoteCursorHot = { x: ev.hotx, y: ev.hoty };
        this.updateRemoteCursorTransform();
        break;
      }
      case 'cursorPos':
        this.positionRemoteCursor(ev.x, ev.y);
        break;
      case 'clipboard': {
        if (!this.clipboardEnabled || this.permissions.Clipboard === false) break;
        const sessionEpoch = this.sessionEpoch;
        // A successful sync is silent, like the native client; only the
        // fallback needs the user's attention.
        void navigator.clipboard
          ?.writeText(ev.text)
          .catch(() => {
            if (sessionEpoch === this.sessionEpoch) {
              this.toast(tl('remote_clipboard_received_press_ctrl'));
            }
          });
        break;
      }
      case 'chat':
        this.onChat(ev.text);
        break;
      case 'voiceCall':
        this.onVoiceCall(ev.state, ev.detail);
        break;
      case 'h264':
        this.pushMseFrame(ev.data, ev.key);
        break;
      case 'permission':
        this.applyPermission(ev.kind, ev.enabled);
        break;
      case 'privacyMode':
        this.applyPrivacyModeState(ev.state, ev.details, ev.implKey);
        break;
      case 'blockInput':
        this.applyBlockInputState(ev.state, ev.details);
        break;
      case 'elevation':
        if (ev.state === 'succeeded') this.toast(tl('elevation_approved'));
        else if (ev.state === 'failed') this.toast(tl('elevation_failed') + (ev.detail ? `: ${ev.detail}` : ''));
        else this.toast(tl('elevation_approved_waiting_for_elevated'), true);
        break;
      case 'credentials':
        // An address-book credential is the console's, for this session only:
        // never offered to "Save password".
        if (ev.fromAddressBook) this.connectedWithAddressBook = true;
        else this.pendingHashHex = ev.hashHex; // persisted only once the session streams
        this.sessionHashHex = ev.hashHex; // in-memory: reused by the file panel
        if (this.reconnectConfig) this.reconnectConfig.savedHashHex = ev.hashHex;
        break;
      case 'uac':
        if (ev.on) {
          this.toast(tl('uac_prompt_is_open_on'), true);
        } else {
          this.hideToast();
          this.toast(tl('remote_uac_dialog_closed'));
        }
        break;
      case 'msgbox': {
        // "wait-*" types (e.g. wait-uac) stay up until the situation resolves;
        // everything else is a normal transient notification.
        const text = ev.text || ev.title;
        if (!text) break;
        this.toast(ev.title && ev.text ? `${ev.title}: ${ev.text}` : text, /^wait/i.test(ev.msgtype));
        break;
      }
      case 'twoFactor':
        this.onTwoFactor(ev.wrong);
        break;
      case 'loginError':
        this.clearRestartFlow();
        this.teardown();
        this.hideTwoFactor();
        if (this.connectedWithSavedHash) {
          // The stored credential no longer works (password changed) — drop it.
          clearSavedHash(this.peerId);
          this.el.saveCheckbox.checked = false;
          this.el.passwordInput.placeholder = tl('enter_password');
          this.connectedWithSavedHash = false;
        }
        let loginMessage = ev.message || tl('login_failed');
        if (this.connectedWithAddressBook) {
          // Out of date in the address book: the next Connect asks instead.
          this.addressBookRefused = true;
          this.connectedWithAddressBook = false;
          this.el.passwordInput.placeholder = tl('enter_password');
          loginMessage = `${tl('address_book_password_refused')} (${loginMessage})`;
        }
        // A share viewer has no password to try: only the person at the device can let them in.
        if (this.share) loginMessage = `${tl('share_refused')} (${ev.message || tl('login_failed')})`;
        this.showOverlay();
        this.setOverlayBusy(false);
        this.setOverlayError(loginMessage);
        this.el.passwordInput.focus();
        this.el.passwordInput.select();
        break;
    }
  }

  private persistCredentialIfWanted(): void {
    if (this.share) return;
    if (!this.el.saveCheckbox.checked) {
      clearSavedHash(this.peerId);
      return;
    }
    // A freshly-typed password emits a new hash; a reused saved hash keeps the stored one.
    if (this.pendingHashHex) saveSavedHash(this.peerId, this.pendingHashHex);
  }

  /** The line under the peer name: state while in flight, identity once live. */
  private refreshPeerSub(): void {
    if (this.state === 'streaming') {
      const bits = [tl('online')];
      if (this.peerPlatform) bits.push(this.peerPlatform);
      this.el.peerSub.textContent = bits.join(' · ');
    } else {
      this.el.peerSub.textContent = STATE_LABEL[this.state];
    }
  }

  private setState(state: SessionState, detail?: string): void {
    this.state = state;
    this.watchShareWait(state);
    this.renderVoiceCall();
    this.el.root.dataset.state = state;
    this.refreshPeerSub();
    switch (state) {
      case 'streaming':
        if (!this.streamStartMs) this.streamStartMs = Date.now();
        this.maybeShowHomeScreenHint();
        this.hideTwoFactor();
        this.persistCredentialIfWanted();
        this.hideOverlay();
        this.canvas.focus();
        if (this.restartFlow) {
          // Back in time: the deadline no longer applies to this attempt.
          clearTimeout(this.restartFlow.deadlineTimer);
          this.restartFlow.deadlineTimer = undefined;
          this.restartFlow.reconnecting = false;
        }
        if (this.restartFlow?.kind === 'drop') {
          // Back. Keep the flow a little longer: a second drop right after
          // continues the same back-off instead of starting over.
          const flow = this.restartFlow;
          this.el.reconnectCancel.hidden = true;
          clearTimeout(flow.stableTimer);
          this.toast(tl('reconnected'));
          if (this.keyboardBeforeReconnect) this.kbdSink.focus({ preventScroll: true });
          flow.stableTimer = setTimeout(() => {
            if (this.restartFlow === flow && this.state === 'streaming') this.clearRestartFlow();
          }, 15_000);
        } else if (this.restartFlow) {
          const flow = this.restartFlow;
          this.el.reconnectCancel.hidden = true;
          clearTimeout(flow.stableTimer);
          this.toast(tl('connection_restored_checking_stability_a'), true);
          flow.stableTimer = setTimeout(() => {
            if (this.restartFlow !== flow || this.state !== 'streaming') return;
            this.clearRestartFlow();
            this.toast(tl('connection_restored_after_restart_reques'));
          }, 15_000);
        }
        this.showClipboardSyncOffer();
        break;
      case 'error':
        this.teardown();
        this.hideTwoFactor();
        this.clearSecurityState();
        this.destroyAdvancedPanels();
        this.filePanel?.destroy();
        this.filePanel = undefined;
        this.closeSide();
        this.closePop();
        this.showOverlay();
        this.setOverlayBusy(false);
        this.setOverlayError(detail || tl('connection_failed'));
        break;
      case 'closed':
        this.teardown();
        this.hideTwoFactor();
        this.clearSecurityState();
        this.destroyAdvancedPanels();
        this.filePanel?.destroy();
        this.filePanel = undefined;
        this.closeSide();
        this.closePop();
        this.showOverlay();
        this.setOverlayBusy(false);
        // A share viewer is told why (the link ended).
        this.setOverlayStatusText(this.share && detail ? detail : tl('disconnected'));
        break;
      default:
        this.showOverlay();
        this.setOverlayBusy(true);
        this.setOverlayStatusText(STATE_LABEL[state] + (detail ? ` — ${detail}` : '') + '…');
    }
    this.syncShareCard();
  }

  private onStats(s: SessionStats): void {
    this.stats = s;
    this.el.statCodec.textContent = s.codec || '—';
    this.el.statRes.textContent = s.width && s.height ? `${s.width}×${s.height}` : '—';
    this.el.statFps.textContent = String(Math.round(s.fps));
    this.el.statBitrate.textContent = formatMbps(s.mbps);
    this.el.statDropped.textContent = String(s.framesDropped);
    if (this.adaptiveFps) {
      const next = adaptFps({
        target: this.adaptiveFpsTarget,
        droppedDelta: Math.max(0, s.framesDropped - this.lastDroppedFrames),
        stableSamples: this.adaptiveStableSamples,
        cap: this.customFps,
      });
      this.adaptiveStableSamples = next.stableSamples;
      if (next.target !== this.adaptiveFpsTarget) {
        this.adaptiveFpsTarget = next.target;
        this.post({ c: 'customFps', fps: this.adaptiveFpsTarget });
      }
      this.lastDroppedFrames = s.framesDropped;
    }
  }

  private positionRemoteCursor(x: number, y: number): void {
    const display = this.displays[this.current];
    if (!this.showRemoteCursor || !display || !canUseRemoteCursor(this.peerPlatform, display)) {
      this.el.remoteCursor.hidden = true;
      return;
    }
    const surface = this.videoEl.hidden ? this.canvas : this.videoEl;
    const canvasRect = surface.getBoundingClientRect();
    const viewportRect = this.el.viewport.getBoundingClientRect();
    const point = mapRemoteCursorToCanvas(
      { x, y },
      display,
      {
        left: canvasRect.left - viewportRect.left,
        top: canvasRect.top - viewportRect.top,
        width: canvasRect.width,
        height: canvasRect.height,
      },
    );
    if (!point) {
      this.el.remoteCursor.hidden = true;
      return;
    }
    this.el.remoteCursor.style.left = `${point.x}px`;
    this.el.remoteCursor.style.top = `${point.y}px`;
    this.el.remoteCursor.hidden = false;
    this.updateRemoteCursorTransform();
  }

  private updateRemoteCursorTransform(): void {
    const x = -this.remoteCursorHot.x * this.cursorScale;
    const y = -this.remoteCursorHot.y * this.cursorScale;
    this.el.remoteCursor.style.transform = `translate(${x}px, ${y}px) scale(${this.cursorScale})`;
  }

  private applyPrivacyModeState(state: number, details: string, implKey: string): void {
    this.privacyModePending = false;
    let failed = false;
    switch (state) {
      case BackNotification_PrivacyModeState.PrvOnByOther:
      case BackNotification_PrivacyModeState.PrvOnSucceeded:
        this.privacyModeOn = true;
        this.activePrivacyImplKey = implKey || this.activePrivacyImplKey;
        break;
      case BackNotification_PrivacyModeState.PrvOffSucceeded:
      case BackNotification_PrivacyModeState.PrvOffByPeer:
        this.privacyModeOn = false;
        this.activePrivacyImplKey = '';
        break;
      case BackNotification_PrivacyModeState.PrvNotSupported:
        this.privacyModeOn = false;
        this.privacyModeSupported = false;
        failed = true;
        break;
      case BackNotification_PrivacyModeState.PrvOnFailedDenied:
      case BackNotification_PrivacyModeState.PrvOnFailedPlugin:
      case BackNotification_PrivacyModeState.PrvOnFailed:
        this.privacyModeOn = false;
        failed = true;
        break;
      case BackNotification_PrivacyModeState.PrvOffFailed:
        this.privacyModeOn = true;
        failed = true;
        break;
      default:
        failed = true;
    }
    if (failed) this.toast(tl('privacy_failed') + (details ? `: ${details}` : ''));
    else this.refreshSecurityToast();
  }

  private applyBlockInputState(state: number, details: string): void {
    this.blockInputPending = false;
    let failed = false;
    switch (state) {
      case BackNotification_BlockInputState.BlkOnSucceeded:
        this.blockInputOn = true;
        break;
      case BackNotification_BlockInputState.BlkOffSucceeded:
        this.blockInputOn = false;
        break;
      case BackNotification_BlockInputState.BlkOnFailed:
        this.blockInputOn = false;
        failed = true;
        break;
      case BackNotification_BlockInputState.BlkOffFailed:
        this.blockInputOn = true;
        failed = true;
        break;
      default:
        failed = true;
    }
    if (failed) this.toast(tl('input_control_failed') + (details ? `: ${details}` : ''));
    else this.refreshSecurityToast();
  }

  private refreshSecurityToast(): void {
    if (this.blockInputOn) this.toast(tl('remote_keyboard_and_mouse_are'), true);
    else if (this.privacyModeOn) this.toast(tl('privacy_mode_is_active'), true);
    else this.hideToast();
  }

  private releaseRemoteSecurityState(): void {
    // A disconnect can race the peer's acknowledgement of an enable request.
    // Compensate for both confirmed and pending intrusive state before closing.
    if (this.blockInputOn || this.blockInputPending) this.post({ c: 'blockInput', on: false });
    if ((this.privacyModeOn || this.privacyModePending) && this.activePrivacyImplKey) {
      this.post({ c: 'privacyMode', implKey: this.activePrivacyImplKey, on: false });
    }
    this.blockInputOn = false;
    this.blockInputPending = false;
    this.privacyModeOn = false;
    this.privacyModePending = false;
  }

  private clearSecurityState(): void {
    this.privacyModeSupported = false;
    this.privacyModeImpls = [];
    this.privacyModeOn = false;
    this.privacyModePending = false;
    this.activePrivacyImplKey = '';
    this.blockInputOn = false;
    this.blockInputPending = false;
    this.lockAfterSessionEnd = false;
    this.hideToast();
  }

  // --- permissions / misc ------------------------------------------------------

  // Keep ?lo=1 in the URL in sync with "the user logged out on purpose".
  private setLoggedOutFlag(on: boolean): void {
    setLoggedOutParam(on);
  }

  /**
   * Apply a peer-advertised permission to the chrome.
   *
   * The peer is the only thing that ENFORCES these — a server policy (a
   * CortenDesk strategy, or the user's own settings) is applied on the
   * controlled machine, and it will refuse the capability whatever this client
   * does. Gating here is purely so the operator sees a disabled control instead
   * of clicking one that silently fails.
   *
   * Permissions are assumed granted until the peer says otherwise: it reports
   * the restricted ones after login, and anything it never mentions is allowed.
   */
  private applyPermission(kind: string, enabled: boolean): void {
    this.permissions[kind] = enabled;
    if (kind === 'Restart' && !enabled && this.restartFlow) {
      const sessionStillStreaming = this.state === 'streaming';
      this.clearRestartFlow();
      if (sessionStillStreaming) this.toast(tl('restart_permission_was_denied_by'));
      else this.setState('error', tl('automatic_reconnect_stopped_because_rest'));
    }

    if (kind === 'Audio') {
      if (!enabled) {
        this.audioPlayback?.reset();
        if (this.voiceCallState !== 'idle') this.endVoiceCall(true);
      }
      this.renderVoiceCall();
    }
    if (kind === 'Clipboard' && !enabled) this.removeClipboardSyncOffer();
    if (kind === 'Recording' && !enabled && this.recording) this.recorder?.stop();

    const target = PERMISSION_CONTROLS[kind];
    if (!target) {
      if (kind === 'Audio' || kind === 'Recording') {
        this.toast(tl('peer_toggled', { state: tl(enabled ? 'enabled' : 'disabled'), what: lowerLabel(tl(kind.toLowerCase())) }));
      }
      return; // nothing in the chrome maps to it
    }

    if (kind === 'Keyboard') this.xkeys.setEnabled(enabled);
    const ids = kind === 'Keyboard' ? [target.id, ...KEYBOARD_EXTRA_IDS] : [target.id];
    for (const id of ids) {
      const el = this.el.root.querySelector<HTMLButtonElement>(`#${id}`);
      if (!el) continue;
      el.disabled = !enabled;
      if (id === target.id) {
        el.title = enabled ? target.title : tl('not_permitted', { what: target.title });
        el.setAttribute('aria-label', el.title);
      }
    }

    // A capability withdrawn mid-session has to close what it opened.
    if (kind === 'File') {
      this.el.edge
        .querySelector<HTMLButtonElement>('[data-open="files"]')
        ?.toggleAttribute('disabled', !enabled);
      if (!enabled) {
        this.filePanel?.destroy();
        this.filePanel = undefined;
        if (this.sideOpen && this.sideTab === 'files') this.closeSide();
      }
    }

    this.toast(tl('peer_toggled', { state: tl(enabled ? 'enabled' : 'disabled'), what: lowerLabel(target.title) }));
  }

  /** Forget peer permissions — they belong to one session, not to the client. */
  private resetPermissions(): void {
    this.permissions = {};
    this.xkeys?.setEnabled(true);
    const all = new Set<string>(KEYBOARD_EXTRA_IDS);
    for (const { id } of Object.values(PERMISSION_CONTROLS)) all.add(id);
    for (const id of all) {
      const el = this.el.root.querySelector<HTMLButtonElement>(`#${id}`);
      if (el) el.disabled = false;
    }
    for (const { id, title } of Object.values(PERMISSION_CONTROLS)) {
      const el = this.el.root.querySelector<HTMLButtonElement>(`#${id}`);
      if (el) {
        el.title = title;
        el.setAttribute('aria-label', title);
      }
    }
    this.el.edge
      .querySelector<HTMLButtonElement>('[data-open="files"]')
      ?.toggleAttribute('disabled', false);
  }

  /**
   * Feed a forwarded H.264 frame to the MSE player, creating it on first use.
   *
   * Reaching here at all means the worker found no WebCodecs and chose the
   * forwarding pipeline, so the <video> takes over from the canvas: it becomes
   * the visible surface AND the input target, since clicks must map against
   * whatever is actually showing the remote screen.
   */
  private pushMseFrame(data: Uint8Array, key: boolean): void {
    if (!this.msePlayer) {
      this.msePlayer = new MseVideoPlayer(this.videoEl, (msg) => {
        this.toast(msg);
        this.post({ c: 'refresh' });
      });
      this.canvas.hidden = true;
      this.videoEl.hidden = false;
      // Re-point input at the element the operator can actually see.
      this.detach?.();
      this.detach = attachInput(this.videoEl, (c) => this.post(c), () => this.currentRect(), this.inputOptions());
      this.el.viewport.dataset.mse = '1';
    }
    this.msePlayer.push(data, key);
  }

  /** Put the canvas back in charge; called whenever a session ends. */
  private teardownMse(): void {
    if (!this.msePlayer) return;
    this.msePlayer.close();
    this.msePlayer = undefined;
    this.videoEl.hidden = true;
    this.videoEl.removeAttribute('src');
    this.canvas.hidden = false;
    delete this.el.viewport.dataset.mse;
  }

  private createAudioPlayback(): void {
    const AudioContextCtor = (window as unknown as {
      AudioContext?: new () => AudioContext;
      webkitAudioContext?: new () => AudioContext;
    }).AudioContext ?? (window as unknown as { webkitAudioContext?: new () => AudioContext }).webkitAudioContext;
    if (!AudioContextCtor) return;
    try {
      const context = new AudioContextCtor();
      this.audioPlayback = new RemoteAudioPlayback(context as unknown as RemoteAudioContext);
      this.audioPlayback.setVolume(this.audioVolume);
      this.audioPlayback.setMuted(this.audioMuted);
    } catch {
      this.audioPlayback = undefined;
    }
  }

  private async resumeAudioFromUserGesture(): Promise<void> {
    const sessionEpoch = this.sessionEpoch;
    if (!this.audioPlayback || this.permissions.Audio === false) {
      this.toast(tl('remote_audio_is_unavailable'));
      return;
    }
    const resumed = await this.audioPlayback.resumeFromUserGesture();
    const currentPermissions = this.permissions as Record<string, boolean | undefined>;
    if (sessionEpoch !== this.sessionEpoch || currentPermissions.Audio === false) return;
    this.audioStarted = resumed;
    this.toast(resumed ? tl('remote_audio_ready') : tl('browser_blocked_remote_audio_playback'));
  }

  private showClipboardSyncOffer(): void {
    this.removeClipboardSyncOffer();
    if (!this.clipboardEnabled || this.permissions.Clipboard === false || this.state !== 'streaming') return;
    const prompt = document.createElement('div');
    prompt.className = 'rd-clipboard-sync-offer';
    const text = document.createElement('span');
    text.textContent = tl('sync_your_current_clipboard_remote');
    const sync = document.createElement('button');
    sync.type = 'button';
    sync.textContent = tl('sync_now');
    const dismiss = document.createElement('button');
    dismiss.type = 'button';
    dismiss.textContent = tl('not_now');
    dismiss.className = 'rd-quiet';
    sync.addEventListener('click', () => {
      this.removeClipboardSyncOffer();
      void this.sendClipboard();
    });
    dismiss.addEventListener('click', () => this.removeClipboardSyncOffer());
    prompt.append(text, sync, dismiss);
    this.el.viewport.appendChild(prompt);
    this.clipboardSyncPrompt = prompt;
  }

  private removeClipboardSyncOffer(): void {
    this.clipboardSyncPrompt?.remove();
    this.clipboardSyncPrompt = undefined;
  }

  private canRecordSession(): boolean {
    return this.state === 'streaming' && this.permissions.Recording !== false;
  }

  private canSendClipboard(): boolean {
    return remoteInputAllowed(this.viewOnly, 'clipboard')
      && this.clipboardEnabled
      && this.permissions.Clipboard !== false;
  }

  private async toggleRecording(): Promise<void> {
    if (this.recording) {
      this.recorder?.stop();
      return;
    }
    if (!this.canRecordSession()) {
      this.toast(tl('session_recording_is_not_permitted'));
      return;
    }
    const sessionEpoch = this.sessionEpoch;
    if (this.remoteAudioEnabled && this.permissions.Audio !== false && this.audioPlayback) {
      const resumed = await this.audioPlayback.resumeFromUserGesture();
      if (sessionEpoch !== this.sessionEpoch) return;
      if (!this.canRecordSession()) {
        this.toast(tl('session_recording_is_not_permitted'));
        return;
      }
      this.audioStarted = resumed;
    }
    if (sessionEpoch !== this.sessionEpoch) return;
    if (!this.canRecordSession()) {
      this.toast(tl('session_recording_is_not_permitted'));
      return;
    }
    const surface = (!this.videoEl.hidden ? this.videoEl : this.canvas) as unknown as RecordingSurface;
    const recorder = new LocalSessionRecorder(
      surface,
      () => this.audioPlayback?.createRecordingTap() ?? null,
      (active, startedAtMs) => {
        if (sessionEpoch === this.sessionEpoch) this.onRecordingState(active, startedAtMs);
      },
    );
    const result = recorder.start();
    if (!result.ok) {
      recorder.close();
      this.toast(result.reason);
      return;
    }
    this.recorder = recorder;
  }

  private onRecordingState(active: boolean, startedAtMs?: number): void {
    const changed = this.recording !== active;
    const wasRecording = this.recording;
    this.recording = active;
    this.recordingStartedMs = active ? (startedAtMs ?? Date.now()) : 0;
    this.el.recordingIndicator.hidden = !active;
    const time = this.el.recordingIndicator.querySelector('span');
    if (time) time.textContent = '00:00';
    if (changed && this.permissions.Recording !== false) {
      this.post({ c: 'clientRecording', recording: active });
    }
    if (!active) {
      this.recorder = undefined;
      if (wasRecording) this.toast(tl('recording_saved_locally'));
    } else {
      this.toast(tl('recording_locally_nothing_is_uploaded'), true);
    }
  }

  private async sendClipboard(): Promise<void> {
    if (!this.canSendClipboard()) {
      this.toast(tl('text_clipboard_is_disabled_for'));
      return;
    }
    const sessionEpoch = this.sessionEpoch;
    const text = await readLocalClipboardText();
    if (sessionEpoch !== this.sessionEpoch) return;
    if (!this.canSendClipboard()) {
      this.toast(tl('text_clipboard_is_disabled_for'));
      return;
    }
    if (text === null) {
      this.toast(tl('clipboard_unavailable_permission_denied'));
      return;
    }
    this.post({ c: 'clipboardText', text });
    this.toast(tl('clipboard_sent'));
  }

  private async toggleFullscreen(): Promise<void> {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await this.el.root.requestFullscreen();
    } catch {
      this.toast(tl('fullscreen_unavailable'));
    }
  }

  // --- overlay / toast -------------------------------------------------------

  private showOverlay(): void {
    this.el.overlay.classList.remove('rd-hidden');
  }

  private hideOverlay(): void {
    this.el.overlay.classList.add('rd-hidden');
    this.setOverlayBusy(false);
  }

  private setOverlayBusy(busy: boolean): void {
    this.el.connectBtn.disabled = busy;
    this.el.peerIdInput.disabled = busy;
    this.el.passwordInput.disabled = busy;
    if (this.el.twoFactorInput) this.el.twoFactorInput.disabled = busy;
    if (this.el.twoFactorBtn) this.el.twoFactorBtn.disabled = busy;
    if (busy) this.setOverlayError(null);
    else if (!this.el.overlayStatusText.textContent) this.el.overlayStatus.hidden = true;
    this.el.overlayStatus.classList.toggle('rd-busy', busy);
  }

  private setOverlayStatusText(text: string): void {
    this.el.overlayStatus.hidden = false;
    this.el.overlayStatusText.textContent = text;
  }

  private setOverlayError(message: string | null): void {
    this.el.overlayError.hidden = !message;
    this.el.overlayError.textContent = message ?? '';
    if (message) this.el.overlayStatus.hidden = true;
  }

  private toast(msg: string, sticky = false): void {
    const t = this.el.toast;
    t.textContent = msg;
    t.classList.add('rd-show');
    clearTimeout(this.toastTimer);
    if (!sticky) this.toastTimer = setTimeout(() => t.classList.remove('rd-show'), 2600);
  }

  private hideToast(): void {
    clearTimeout(this.toastTimer);
    this.el.toast.classList.remove('rd-show');
  }

  private destroyAdvancedPanels(): void {
    this.terminalPanel?.destroy();
    this.terminalPanel = undefined;
    this.cameraPanel?.destroy();
    this.cameraPanel = undefined;
  }

  dispose(): void {
    this.clearRestartFlow();
    this.teardown();
    this.filePanel?.destroy();
    this.filePanel = undefined;
    this.destroyAdvancedPanels();
    this.closePop();
    if (this.ticker) clearInterval(this.ticker);
  }
}

if (typeof document !== 'undefined' && typeof Worker !== 'undefined') {
  // ?mode=terminal opens a terminal straight away, with no remote screen.
  const start = (): void => {
    if (terminalModeFromSearch(location.search)) new TerminalApp().mount();
    else new RdApp().mount();
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
}
